#ifndef __INIT_H
#define __INIT_H

extern void init(const char*) ;

#endif
