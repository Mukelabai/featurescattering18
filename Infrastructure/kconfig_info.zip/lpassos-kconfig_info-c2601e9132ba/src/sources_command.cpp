#include "sources_command.h"

#include <iostream>
#include <cstring>
#include <fstream>
#include <stack>
#include <set>

#include <lkc.h>

SourcesCommand::SourcesCommand() {
	Command::name = "--sources" ;
	Command::usage = "[output]" ;
	Command::help = "list all sources included from a top level Kconfig file and save to output file (stdout by default)" ;

	SourcesCommand::outputFile = "out" ;
}

void SourcesCommand::parseParams(int argc, char** params) {
	if (argc == 1) {
		outputFile = params[0] ;
	}
	else if (argc > 1) {
		throw std::string("incorrect number of parameters. Expecting only file name.") ;
	}
	else
		outputFile = "" ;
}

const std::string& SourcesCommand::run() {

	std::ostream* out = NULL ;
	std::ofstream ofile ;

	if (outputFile.length() == 0)
		out = &std::cout ;
	else {
		ofile.open(outputFile.c_str()) ;

		if (! ofile.is_open())
			throw std::string("cannot create file " + outputFile) ;

		out = &ofile ;
	}

	struct file* file ;
	long count = 0 ;

	for (file = file_list; file; file = file->next) {
		(*out) << file->name << std::endl ;
		count++ ;
	}

	if (ofile.is_open())
		ofile.close() ;


	char s_files[100] ;
	sprintf(s_files, "%ld", count) ;

	result = "Total # of files: " + std::string(s_files) ;
	return result ;
}
