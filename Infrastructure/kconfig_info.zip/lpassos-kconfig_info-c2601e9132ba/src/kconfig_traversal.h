#ifndef __KCONFIG_TRAVERSAL_
#define __KCONFIG_TRAVERSAL_

#include  <lkc.h>
#include <set>
#include <stack>
#include <iostream>

template <class T> class KconfigTraversal {

public:
	class OnNodeFoundEvent {

		protected:
			bool _continue ;

		public:

			OnNodeFoundEvent() { _continue = true ; }

			virtual void operator()  (const struct menu*, const struct menu*, T) = 0;

			virtual void done() { 	}

			bool shouldContinue() { return _continue ; }
			void setContinue(bool _continue) { this->_continue = _continue ; }

	};

private:

	OnNodeFoundEvent* onNodeFound ;

public:
	KconfigTraversal(OnNodeFoundEvent* onNodeFound) {
		this->onNodeFound = onNodeFound ;
	}

	void run(struct menu* root, T& data) {

		std::stack<const struct menu*> stk ;
		stk.push(root) ;

		while(! stk.empty()) {
			const struct menu* node = stk.top() ;
			stk.pop() ;

			(*onNodeFound)(node, node->parent, data) ;

			if (! onNodeFound->shouldContinue())
				return ;

			/* Must continue */
			for(struct menu* child = node->list; child; child = child->next) {
				stk.push(child) ;
			}
		}
	}
};

#endif /* __KCONFIG_TRAVERSAL_H_ */
