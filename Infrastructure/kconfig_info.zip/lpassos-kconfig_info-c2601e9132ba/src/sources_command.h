#ifndef __SOURCES_COMMAND_H
#define __SOURCES_COMMAND_H

class SourcesCommand ;

#include "command.h"

class SourcesCommand : public Command {
private:
	std::string outputFile ;
public:
	SourcesCommand();
	void parseParams(int, char**) ;
	const std::string& run();
};

#endif
