#include "features_command.h"
#include "incorrect_usage.h"

#include <iostream>
#include <cstring>
#include <fstream>
#include <stack>
#include <set>

#include <lkc.h>

FeaturesCommand::FeaturesCommand() {
	Command::name = "--features" ;
	Command::usage = "[output file]" ;
	Command::help = "list all features of a Kconfig top level file and save to output file (stdout by default)" ;
}

void FeaturesCommand::parseParams(int argc, char** params) {
	if (argc == 1) {
		outputFile = params[0] ;
	}
	else if (argc > 1) {
		throw INCORRECT_NBR_OF_PARAMS("Expecting output file name.") ;
	}
	else
		outputFile = "" ;
}

const std::string& FeaturesCommand::run() {

	std::ostream* out = NULL ;
	std::ofstream ofile ;

	if (outputFile.length() == 0)
		out = &std::cout ;
	else {
		ofile.open(outputFile.c_str()) ;

		if (! ofile.is_open())
			throw std::string("cannot create file " + outputFile) ;

		out = &ofile ;
	}

	OnNodeFoundHandler onNodeFound ;
	KconfigTraversal<std::ostream&> dfs(&onNodeFound) ;

	dfs.run(&rootmenu, *out) ;

	/*std::stack<struct menu*> stk ;
	stk.push(&rootmenu) ;

	while(! stk.empty()) {
		struct menu* menu = stk.top() ;
		stk.pop() ;

		if (menu->sym && menu->sym->name && features.find(std::string(menu->sym->name)) == features.end()) {
			(*out) << menu->sym->name << std::endl ;
			features.insert(std::string(menu->sym->name)) ;
		}

		for(struct menu* child = menu->list; child; child = child->next) {
			stk.push(child) ;
		}
	}*/

	if (ofile.is_open())
		ofile.close() ;


	char s_features[100] ;
	sprintf(s_features, "%zu", onNodeFound.getFeatures().size()) ;

	result = "Total # of features: " + std::string(s_features) ;
	return result ;
}
