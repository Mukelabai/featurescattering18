#ifndef __FEATURES_COMMAND_H
#define __FEATURES_COMMAND_H

class FeaturesCommand ;

#include "command.h"
#include "kconfig_traversal.h"

#include <lkc.h>

#include <iostream>

class FeaturesCommand : public Command {
private:

	/* .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .*/
	class OnNodeFoundHandler : public KconfigTraversal<std::ostream&>::OnNodeFoundEvent {

	private:
		std::set<std::string> features ;
		bool clearOnNextRun ;

	public:

		OnNodeFoundHandler() {
			this->clearOnNextRun = false ;
		}

		void operator()  (const struct menu* child, const struct menu* parent, std::ostream& out) {

			if (clearOnNextRun)
				features.clear() ;

			if (child->sym && child->sym->name && features.find(std::string(child->sym->name)) == features.end()) {
				out << (child->sym->name) << std::endl ;
				features.insert(std::string(child->sym->name)) ;
			}
		}

		std::set<std::string>& getFeatures() { return features ; }

		virtual void done() {
			this->clearOnNextRun = true ;
		}
	};

	/* .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .*/

	std::string outputFile ;

public:
	FeaturesCommand();
	void parseParams(int, char**) ;
	const std::string& run();
};

#endif
