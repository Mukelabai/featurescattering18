#include "init.h"

/* Kconfig parser and related functions */
#include <lkc.h>

static inline void fixup_rootmenu(struct menu *menu)
{
#ifndef OLD_KCONFIG
	struct menu *child;
	static int menu_cnt = 0;

	menu->flags |= MENU_ROOT;
	for (child = menu->list; child; child = child->next) {
		if (child->prompt && child->prompt->type == P_MENU) {
			menu_cnt++;
			fixup_rootmenu(child);
			menu_cnt--;
		} else if (!menu_cnt)
			fixup_rootmenu(child);
	}
#endif
}

void init(const char* kconfig_file) {

#ifdef BINDING_SUPPORT
#pragma warning("no binding support")

	bindtextdomain(PACKAGE, LOCALEDIR);
	bind_textdomain_codeset(PACKAGE, "UTF-8");
	textdomain(PACKAGE);

#endif

	conf_parse(kconfig_file);
	fixup_rootmenu(&rootmenu);
	conf_read(NULL);
}
