#ifndef __FEATURE_COMMAND_INFO_H
#define __FEATURE_COMMAND_INFO_H

class FeatureInfoCommand ;

#include "command.h"
#include "kconfig_traversal.h"

#include <lkc.h>

#include <string>

class FeatureInfoCommand : public Command {

private:
	/* .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .*/
	class OnNodeFoundHandler : public KconfigTraversal<std::string&>::OnNodeFoundEvent {

	private:
		const menu* child ;
		const menu* parent ;

	public:

		OnNodeFoundHandler() : OnNodeFoundEvent() {
			child = parent = NULL ;
		}


		void operator()  (const struct menu* child, const struct menu* parent, std::string& featureName) {
			if (child->sym && child->sym->name && (std::string(child->sym->name) == featureName)) {
				this->child = child ;
				this->parent = parent ;
				setContinue(false) ;
			}
		}

		const menu* getChild()    { return child ; }
		const menu* getParent() { return parent ; }
	};

	/* .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .*/

	std::string featureName ;

public:
	FeatureInfoCommand();
	void parseParams(int, char**) ;
	const std::string& run();
};

#endif
