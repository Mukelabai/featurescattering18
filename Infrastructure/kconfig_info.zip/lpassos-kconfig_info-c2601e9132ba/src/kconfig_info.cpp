//============================================================================
// Name        : kconfig_info.cpp
// Author      : Leonardo Passos
// Version     :
// Copyright   : 
// Description :
//============================================================================

/* C++ standard library headers */
#include <iostream>
#include <sstream>
#include <fstream>
#include <cstdlib>
#include <vector>

/* GNU C++ extensions */
#include <ext/stdio_filebuf.h>

/* C header files (C++ compliant) */
#include <cstdio>
#include <cstdlib>
#include <cstring>

/* C header files */
#include <unistd.h>
#include <errno.h>

/* Kconfig headers */
#include "init.h"

/* Custom headers */
#include "features_command.h"
#include "sources_command.h"
#include "feature_info_command.h"


/* . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .*/

bool fileExists(const char* filename) {
	std::fstream f(filename, std::ios::in);
	bool exists = false ;
	if (f.good())
		exists = true ;
	f.close() ;
	return exists ;
}

/* . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .*/

bool fileExists(std::string& s) {
	return fileExists(s.c_str()) ;
}

/* . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .*/

void showHelp(const std::vector<Command*>& commands, bool shouldExit=true) {
	std::cerr << "Usage: kconfig_info [cmd] [cmd-args]" << std::endl ;
	std::cerr << "  " << "where cmd is one of" << std::endl ;
	for(std::vector<Command*>::const_iterator it  = commands.begin(); it != commands.end(); it++) {
		std::cerr << "    " << (*it)->getInfo() << std::endl ;
	}
	if (shouldExit)
		exit(EXIT_FAILURE) ;
}

/* . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .*/

char* getRootKconfig() {
	char* root = getenv("ROOT_KCONFIG1") ;
	if (root && fileExists(root))
		return root ;

	root = getenv("ROOT_KCONFIG2") ;
	if (root && fileExists(root))
		return root ;

	root = getenv("ROOT_KCONFIG3") ;
	if (root && fileExists(root))
		return root ;

	root = getenv("ROOT_KCONFIG4") ;
	return root ;
}

/* . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .*/

int main(int argc, char** argv) {

	std::vector<Command*> commands ;
	commands.push_back(new FeaturesCommand()) ;
	commands.push_back(new FeatureInfoCommand()) ;

	if (argc < 2)
		showHelp(commands) ;

	Command* cmd = (Command*) 0;
	try {

		for(std::vector<Command*>::iterator it  = commands.begin(); it != commands.end(); it++) {
			if ((*it)->getName() == argv[1]) {
				cmd = (*it) ;
				break ;
			}
		}

		if (! cmd)
			throw std::string("command not found") ;

	} catch(const std::string& msg) {
		std::cerr << "Incorrect usage: " << msg << std::endl ;
		showHelp(commands) ;
	}

	char* rootKconfig = getRootKconfig() ;
	if (rootKconfig) {
		std::cout << "Using root Kconfig file" << std::endl ;
		init(rootKconfig) ;
	}
	else {
		std::cerr << "Cannot find the main Kconfig!" << std::endl ;
		exit(EXIT_FAILURE) ;
	}

	try {
	  const std::string& res = cmd->parseParamsAndRun(argc - 2, &argv[2]) ;

	   if (res.length() > 0)
		  std::cout << res << std::endl ;
	} catch(std::string& msg) {
		std::cerr << "Error: " << msg << std::endl ;
		return EXIT_FAILURE;
	}

	return EXIT_SUCCESS;
}

/* . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .*/
