#include "feature_info_command.h"
#include "incorrect_usage.h"

#include <iostream>
#include <cstring>
#include <string>
#include <fstream>
#include <sstream>
#include <stack>

#include <lkc.h>
#include <expr.h>

static void writeParent(std::string&, const menu*, const menu*) ;

static void writeHasPrompt(std::string&, const menu*) ;
static void writeIsChoice(std::string&, const menu*) ;

static void writeChildren(std::string&, const menu*) ;
static void writeType(std::string&, const menu*) ;
static void writeDefault(std::string&, const menu*) ;
static void writeDep(std::string&, const menu*) ;

static void exprToString(struct expr*, std::string&) ;
//static int MAX_LENGTH = 10000 ;

FeatureInfoCommand::FeatureInfoCommand() {
	Command::name = "--feature-info" ;
	Command::usage = "<feature-name>" ;
	Command::help = "prints various information related to the input feature name" ;
}

void FeatureInfoCommand::parseParams(int argc, char** params) {
	if (argc == 1) {
		featureName = params[0] ;
	}
	else
		throw INCORRECT_NBR_OF_PARAMS("Expecting feature name.") ;
}

const std::string& FeatureInfoCommand::run() {

	OnNodeFoundHandler onNodeFound ;
	KconfigTraversal<std::string&> dfs(&onNodeFound) ;

	dfs.run(&rootmenu, featureName) ;

	if (! onNodeFound.getChild())
		result = "Feature not found" ;

	else {
		writeParent(result, onNodeFound.getChild(), onNodeFound.getParent()) ;
		result += "\n" ;

		writeHasPrompt(result, onNodeFound.getChild()) ;
		result += "\n" ;

		writeIsChoice(result, onNodeFound.getChild()) ;
		result += "\n" ;

		writeType(result, onNodeFound.getChild()) ;
		result += "\n" ;

		writeDefault(result, onNodeFound.getChild()) ;
		result += "\n" ;

		writeDep(result, onNodeFound.getChild()) ;
		result += "\n" ;

		writeChildren(result, onNodeFound.getChild()) ;
	}

	return result ;
}

void writeParent(std::string& s, const menu* featureNode, const menu* parentNode) {

	s += "Parent: " ;

	/* Checks if child is a root feature. */
	if (featureNode == (&rootmenu))
		s += "Root" ;

	/* Checks if child has no parent. */
	else if (! parentNode)
		s += "Orphanage feature" ;

	else if (parentNode->sym || parentNode->prompt) {

		if (parentNode->sym) {

			if (sym_is_choice(parentNode->sym))
				s += "choice " ;

			/* Checks if child has a parent with a name. */
			if (parentNode->sym->name)
				s += ( std::string(parentNode->sym->name) + " " ) ;
		}

		if (parentNode->prompt && parentNode->prompt->text)
			s += ("\"" + std::string(parentNode->prompt->text) + "\"");

	}
	else
		s += "unnamed" ;
}

void writeHasPrompt(std::string& s, const menu* featureNode) {
	s += "Has prompt: " ;
	if (featureNode->prompt)
		s += "true" ;
	else
		s += "false" ;
}

void writeIsChoice(std::string& s, const menu* node) {
	s += "Is choice: " ;
	if (node->sym && sym_is_choice(node->sym))
		s += "true" ;
	else
		s += "false" ;
}

void writeChildren(std::string& s, const menu* node) {
	s += "Children: " ;

	for(struct menu* child = node->list; child; child = child->next)
		if (child->sym && child->sym->name) {
			s += child->sym->name;
			s += " " ;
		}
}

void writeType(std::string& s, const menu* node) {
	s += ("Type: " + std::string(sym_type_name(sym_get_type(node->sym))));
}

void exprToString(struct expr *e, std::string& buf) {
    if (! e) {
        return;
    }

	//if (expr_is_yes(e)) {
	//	buf.append("y") ;
	//	return ;
	//}

	//if (expr_is_no(e)) {
	//	buf.append("n") ;
	//	return ;
	//}

	//struct gstr e_str = str_new();
	//char c_buf[MAX_LENGTH];

    //expr_gstr_print(e, &e_str);
    //strcpy(c_buf, str_get(&e_str));

    //buf.append(std::string(c_buf)) ;

    //str_free(&e_str);

    char* bp ;
    size_t size ;
    FILE* stream = open_memstream(&bp, &size) ;

    expr_fprint(e, stream) ;
    fclose(stream) ;

    buf.append(std::string(bp)) ;
}

void writeDefault(std::string& s, const menu* node) {

	bool found = false ;
	s += "Default: " ;

	for (struct property *prop = node->sym->prop; prop; prop = prop->next) {

		switch (prop->type) {

			case P_DEFAULT: /* default y */ {

				// In older Kconfig releases, a default was restricted
				// to a single symbol (not an expression)

            #if defined(OLD_KCONFIG)
				s += (prop->def->name) ;
			#else
				exprToString(prop->expr, s);
			#endif

				std::string visibility ;
				exprToString(prop->visible.expr, visibility);

				if (! visibility.empty())
					s += (" if " + visibility) ;
			}

			break;

			default:
				/* Do nothing */
				break ;
		}
	}

}

void writeDep(std::string& s, const menu* node) {

	std::string dep ;
	exprToString(node->dep, dep);

	s += ("Dependency: " + dep) ;
}

