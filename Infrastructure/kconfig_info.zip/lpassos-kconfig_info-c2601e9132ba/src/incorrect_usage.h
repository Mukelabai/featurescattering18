#ifndef INCORRECT_USAGE_H
#define INCORRECT_USAGE_H

#define INCORRECT_NBR_OF_PARAMS(s) (std::string("incorrect number of parameters: ") + std::string(s))

#endif
