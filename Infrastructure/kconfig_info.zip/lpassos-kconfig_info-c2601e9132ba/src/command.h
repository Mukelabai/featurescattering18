#ifndef __COMMAND_H
#define __COMMAND_H

class Command ;

#include<string>

class Command {
protected:
	std::string name ;
	std::string result ;
	std::string usage ;
	std::string help ;

	const std::string& getUsage() const {
		return usage ;
	}
	const std::string& getHelp() const {
		return help ;
	}

public:
	virtual void parseParams(int argc, char** params) = 0;
	virtual const std::string& run() = 0;

	const std::string& parseParamsAndRun(int argc, char** params) {
		parseParams(argc, params) ;
		return run() ;
	}

	const std::string& getName() const {
		return name ;
	}
	const std::string getInfo() const {
		return name + " " + usage + ": " + help ;
	}

	virtual ~Command() { };
};

#endif
