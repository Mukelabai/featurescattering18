#!/usr/bin/Rscript

# Gets the scattering inside driver

driver_scat_threshold_grps <- plot_subsystem_scat('driver', 
                    drvs_sd_per_subsystem,
                    sd_ystep = 20,                      
                    sd_zoom_ystep = 4,
                    grp_above_abs_ystep = 1,
                    grp_above_rel_ystep = 0.05,
                    grp_bellow_abs_ystep = 20,
                    grp_bellow_rel_ystep = 1.5,
                    hist_xmax = 320, 
                    hist_xstep = 10,
                    hist_ymax = 260,
                    hist_ystep = 10,                                
                    conc_ystep = 5,
                    gini_ystep = 0.05,
                    plot_frames = FALSE)

driver_scat_threshold_grps$scat_subsystem_grps$subsystem = 'driver'

