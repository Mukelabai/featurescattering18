#!/usr/bin/Rscript

# Gets the scattering inside core

core_scat_threshold_grps <- plot_subsystem_scat('core', 
                    drvs_sd_per_subsystem,
                    sd_ystep = 2,                      
                    sd_zoom_ystep = 1,
                    grp_above_abs_ystep = 1,
                    grp_above_rel_ystep = 0.05,
                    grp_bellow_abs_ystep = 10,
                    grp_bellow_rel_ystep = 0.5,
                    hist_xmax = 30, 
                    hist_xstep = 5,
                    hist_ymax = 100,
                    hist_ystep = 10,                                
                    conc_ystep = 5,
                    gini_ystep = 0.05,
                    plot_frames = FALSE)

core_scat_threshold_grps$scat_subsystem_grps$subsystem <- 'core'


