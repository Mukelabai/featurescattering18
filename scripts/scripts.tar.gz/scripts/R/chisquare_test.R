#!/usr/bin/Rscript

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
# Global settings (1)

base_dir <- "/home/leonardo/workspace/modularity2015/scripts/R/"

setwd(base_dir)

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

source("common.R")

scat_grps <- read.csv2(file=csv.file("scat_grps_sample_classified.csv"), 
                       sep=";", header=TRUE)

scat_grps <- sqldf("select * from scat_grps 
                   where ft_criteria <> '?'")
scat_grps <- droplevels(scat_grps)

scat_grps$only_driver <- scat_grps$subsys == 'only driver'
scat_grps$is_plat     <- scat_grps$declares_platform_drv == 'TRUE'
scat_grps$is_infra    <- (scat_grps$ft_kind == 'INFR_CAP' |
                          scat_grps$ft_kind == 'INFR_SUP')
scat_grps$is_bool     <- scat_grps$ft_type == 'bool'

cat("=============================================")

ctg_tbl1 <- table(scat_grps$is_infra, scat_grps$only_driver)
colnames(ctg_tbl1) <- c("not locally scat.", "locally scat.")
rownames(ctg_tbl1) <- c("not infra", "infra")
print(addmargins(ctg_tbl1))
print(chisq.test(ctg_tbl1, correct = FALSE))

cat("=============================================")

ctg_tbl2 <- table(scat_grps$is_plat, scat_grps$only_driver)
colnames(ctg_tbl2) <- c("not locally scat.", "locally scat.")
rownames(ctg_tbl2) <- c("not plat", "plat")
print(addmargins(ctg_tbl2))
print(chisq.test(ctg_tbl2, correct = FALSE))


cat("=============================================")

ctg_tbl3 <- table(scat_grps$is_bool, scat_grps$only_driver)
colnames(ctg_tbl3) <- c("not locally scat.", "locally scat.")
rownames(ctg_tbl3) <- c("not bool", "bool")
print(addmargins(ctg_tbl3))
print(chisq.test(ctg_tbl3, correct = FALSE))