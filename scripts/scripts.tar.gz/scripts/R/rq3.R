#!/usr/bin/Rscript

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

above_threshold  <- 'Above threshold'
bellow_threshold <- 'Bellow or equal threshold'

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

get_scat_drvs_distribution <- function(subsystems) {
  
  scat_drvs_distribution <- dbGetQuery(conn, 
   "select release_id,
           release,
           feature_name,
           subsystem,
           count(*) as total
    
    from scat_drvs_ifdef_refs
    
    group by release_id, 
             release, 
             feature_name, 
             subsystem
    
    order by release_id, release, feature_name"
  )
  
  return(scat_drvs_distribution)  
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

classify_threshold <- function(values, threshold) {
  return(sapply(values, function (x) if (x <= threshold) bellow_threshold else above_threshold))
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

get_scat_threshold_groups <- function(scat_thresholds) {  
  
  scat_drvs <- dbGetQuery(conn, "select * from scat_drvs")
  
  threshold_groups <- sqldf(
    "select release,
            subsystem,
            threshold, 
            count(feature_name) as total,
            100.0 * count(distinct feature_name) / 
            (select count(*)
             from   scat_drvs
             where  scat_drvs.release_id = 
                    scat_thresholds.release_id) as perc

      from scat_thresholds
      group by release_id, release, subsystem, threshold")
  
  return(threshold_groups)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

plot_boxplot_sd <- function(s, scat_dataset, ymax = NULL, ystep = NULL, ht = NULL, out = NULL) {
  
  limits <- plot_box_plot(xvals = scat_dataset$release, 
                          yvals = scat_dataset$total,
                          xlabel = "Release",
                          ymax = ymax,                          
                          ystep = ystep,
                          ht = ht,
                          ylabel = paste(sprintf("SD of driver features\nscattered across %s", s)),
                          out = out)    
  return(limits)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

summarize_growth <- function(s, df, type, above) {
  
  if (nrow(df) == 0)
    cat("There is nothing to summarize (empty dataframe)\n\n")
  
  else {
    header <- paste(sprintf("Scattering growth in %s\n%s the threshold", s, 
                            if (above) "above" else "bellow"))                          
    summarize_evol(if (type == "relative") 
                     df$perc 
                   else 
                     df$total, 
                   header, type, as.numeric(factor(df$release)))
  }
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

plot_growth_threshold <- function(s, scat_dataset, threshold, 
                                  ystart = NULL, ymax = NULL, ystep = NULL, 
                                  ht = NULL, perc, above, out) {
  
   above_type <- if (above) "above" else "bellow"
  
  if (perc) {
    yvals <- scat_dataset$perc
    nbr_type <- "Perc."
  }
  else {
    yvals <- scat_dataset$total
    nbr_type <- "Nbr."
  }  
  
  if (length(yvals) == 0)
    cat("There are no features ", above_type, " theshold: nothing to plot\n")  
  
  else {
    ylabel = paste(sprintf("%s of scattered driver-features\n%s the threshold in %s", nbr_type,
                           above_type, s))
      
    plot_line(xvals = scat_dataset$release, 
              yvals = yvals,
              xlabel = "Release",
              ylabel = ylabel,
              ystart = ystart,            
              #ymax = ymax,
              ystep = ystep,
              discrlabel = sprintf("Threshold (max = %d)", threshold),
              ht = ht,
              out = out) 
  }
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

plot_lorenz_curve <- function(s, r, scat_dataset, above, out_dir_lc = ".") {
  png(filename = sprintf("%s/lc_%s_%s_%s.png", out_dir_lc, s, 
                                  if (above) "above" else "bellow", r))
  
  plot(Lc(scat_dataset$total), 
       main = sprintf("Lorenz curve (%s threshold), release %s", 
                      if (above) "above" else "bellow", r))
  
  invisible(dev.off())       
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

plot_histogram <- function(s, r, scat_dataset, 
                           xmax = NULL, xstep = NULL, 
                           ymax = NULL, ystep = NULL,
                           out_dir_hist = ".") {  
  
  ggplot <- ggplot(scat_dataset, aes(x = total)) + 
    geom_histogram(colour = "black", fill = "white", binwidth = 1) + 
    ggtitle(sprintf("Release %s (scattering in %s)", r, s))  
  
  if ((! is.null(xmax)) && (! is.null(xstep)))
    ggplot <- ggplot + scale_x_continuous(limits=c(0, xmax), breaks=seq(0, xmax, xstep)) 
  
  else if (! is.null(xmax))
    ggplot <- ggplot + xlim(xlim)
  
  if ((! is.null(ymax)) && (! is.null(ystep)))
    ggplot <- ggplot + scale_y_continuous(limits=c(0, ymax), breaks=seq(0, ymax, ystep))
  
  else if (! is.null(ymax))
    ggplot <- ggplot + ylim(ylim)
    
  ggsave(ggplot, file = sprintf("%s/hist_%s_%s.png", out_dir_hist, s, r))
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

plot_lorenz_curves_for_release <- function(s, r, scat_dataset, 
                                           scat_total, above, 
                                           out_dir_lc = ".") {  
    
  scat_grp <- 
    if (above)
      subset(scat_dataset, threshold == above_threshold)  
    else
      subset(scat_dataset, threshold == bellow_threshold)  
  
  gini <- ineq(scat_grp$total)
  
  conc <- 100.0 * sum(scat_grp$total) / scat_total 

  subdir <- if (above) "above" else "bellow"
  
  plot_lorenz_curve(s, r, scat_grp, above, sprintf("%s/%s", out_dir_lc, subdir))

  return(list(gini = gini, concentration = conc))
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

plot_concentration <- function(s, releases, threshold, conc_above, conc_bellow, 
                               ystep = NULL, ht = NULL, out = NULL) {
  
  conc <- rbind(data.frame(release = releases,
                           perc = conc_above,
                           type = above_threshold),
                
                data.frame(release = releases,
                           perc = conc_bellow,
                           type = bellow_threshold))  
  
  plot_line(xvals = conc$release, 
            yvals = conc$perc,
            xlabel = "Release",
            discrlabel = sprintf("Threshold (max = %d)", threshold),
            ylabel = paste(sprintf("Perc. of associated\nscattering in %s", s)),
            ystep = ystep,
            ymax = max(conc$perc),
            discr = conc$type,
            ht = ht, 
            out = out)  
  
  return(conc)  
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

plot_gini <- function(s, releases, threshold, gini_above, gini_bellow, ystep, ht = NULL, out = NULL) {
  
  gini <- rbind(data.frame(release = releases,
                           coef = gini_above,
                           type = 'Above threshold'),
                data.frame(release = releases,
                           coef = gini_bellow,
                           type = 'Bellow or equal threshold'))  
  
  plot_line(xvals = gini$release, 
            yvals = gini$coef,
            xlabel = "Release",
            discrlabel = sprintf("Threshold (max = %d)", threshold),
            ylabel = paste(sprintf("Gini coefficient for scattered\ndriver-features in %s\n", s)),
            discr = gini$type,
            ystep = ystep,
            ht = ht, 
            out = out)  
  
  return(gini)   
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

plot_frames <- function(s, releases, scat_dataset,  threshold, hist_xmax = NULL, hist_xstep = NULL, 
                        hist_ymax = NULL, hist_ystep = NULL, hist_ht = NULL, conc_ystep = NULL, 
                        conc_ht = NULL, print_mcs = FALSE, summarize = TRUE,
                        out_dir_hist = ".",  out_dir_lc = ".",  conc_out = NULL, 
                        gini_ystep = NULL,  gini_ht = NULL, gini_out = NULL) {
  
  gini_bellow <- c()  
  gini_above <- c()
  
  conc_bellow <- c()
  conc_above <- c()
  
  for(r in releases) {  
    
    scat_dataset_r <- subset(scat_dataset, release == r)
    scat_total <- sum(scat_dataset_r$total)    
    
    plot_histogram(s, r, scat_dataset_r, hist_xmax, hist_xstep, hist_ymax, hist_ystep, out_dir_hist)    
    
    # . . . . . . . . . . . . . . . . . . . . . . . . . . .
    # Makes plot for features above threshold
    
    res_above <- plot_lorenz_curves_for_release(s, r, scat_dataset_r, scat_total, 
                                                above = TRUE, out_dir_lc)
    
    gini_above <- c(gini_above, res_above$gini)
    conc_above <- c(conc_above, res_above$concentration)      
    
    # . . . . . . . . . . . . . . . . . . . . . . . . . . .
    # Makes plot for features bellow threshold
    
    res_bellow <- plot_lorenz_curves_for_release(s, r, scat_dataset_r, scat_total, 
                                                 above = FALSE, out_dir_lc)
    
    gini_bellow <- c(gini_bellow,  res_bellow$gini)
    conc_bellow <- c(conc_bellow, res_bellow$concentration)          
    
  }    
  
  conc <- plot_concentration(s, releases, threshold, conc_above, conc_bellow, 
                             ystep = conc_ystep, ht = conc_ht, out = conc_out)    
  
  gini_above <- ifelse(is.nan(gini_above), 0, gini_above)
  gini_bellow <- ifelse(is.nan(gini_bellow), 0, gini_bellow)
  
  if (summarize) {    
    print_header("Concentration growth (above)")
    print_summary(get_growth(conc_above), TRUE)
    print_diff(conc_above)
        
    print_header("Concentration growth (bellow)")
    print_summary(get_growth(conc_bellow), TRUE)
    print_diff(conc_bellow)    
  }    
    
  gini <- plot_gini(s, releases, threshold, gini_above, gini_bellow, 
                    ystep = gini_ystep, ht = gini_ht, out = gini_out)  
  
  if (summarize) {
    print_header("Gini growth (above)")
    print_summary(get_growth(gini_above), TRUE)
    print_diff(gini_above)
    
    print_header("Gini growth (bellow)")
    print_summary(get_growth(gini_bellow), TRUE)
    print_diff(gini_bellow)    
  }   
  
  return(gini)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

plot_subsystem_grp_scat <- function(s, subsystem_scat_grps, threshold, above, summarize = TRUE,
                                    abs_ystart = NULL, abs_ymax = NULL, abs_ystep = NULL, abs_ht = NULL, out_abs = NULL,
                                    rel_ystart = NULL, rel_ymax = NULL, rel_ystep = NULL, rel_ht = NULL, out_rel = NULL) {
    
  scat_subsystem_in_grp <- 
    if (above) {
      subset(subsystem_scat_grps, threshold == above_threshold)
    } else {
      subset(subsystem_scat_grps, threshold == bellow_threshold) 
    }
  
  
  # Plots and summarizes absolute data
  plot_growth_threshold(s, scat_subsystem_in_grp,
                        ystart = abs_ystart, 
                        ymax = abs_ymax,
                        ystep = abs_ystep,
                        ht = abs_ht, 
                        perc = FALSE, 
                        above = above, out = out_abs)  
  
  if (summarize)
    summarize_growth(s, scat_subsystem_in_grp, type = "absolute", above)
  
  
  # Plots and summarizes relative data
  plot_growth_threshold(s, scat_subsystem_in_grp,
                        ystart = rel_ystart,
                        ymax = rel_ymax,
                        ystep = rel_ystep,
                        ht = rel_ht, 
                        perc = TRUE, 
                        above = above, out = out_rel)  
  
  if (summarize)
    summarize_growth(s, scat_subsystem_in_grp, type = "relative", above)  
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
# Main function for RQ3 (from which auxiliary ones are called)

plot_subsystem_scat <- function(s, scat_drvs_distribution,
                                #
                                # Scattering degree parameters
                                #
                                sd_ystep = NULL,
                                sd_ht = NULL,                           
                                sd_out = img.file(sprintf("sd_%s_boxplot.pdf", s)),                                  
                                sd_zoom_ystep = NULL,
                                sd_zoom_ht = NULL,
                                sd_zoom_out = img.file(sprintf("sd_zoom_%s_boxplot.pdf", s)),
                                #
                                # Above (abs) parameters
                                #
                                grp_above_abs_ystep = NULL,                                
                                grp_above_abs_out = img.file(sprintf("gg_%s_above_abs.pdf", s)),
                                #
                                # Above (rel) parameters
                                #
                                grp_above_rel_ystep = NULL,
                                grp_above_rel_out = img.file(sprintf("gg_%s_above_rel.pdf", s)),
                                #
                                # Bellow (abs) parameters
                                #                                
                                grp_bellow_abs_ystep = NULL,
                                grp_bellow_abs_out = img.file(sprintf("gg_%s_bellow_abs.pdf", s)),
                                #
                                # Bellow (rel) parameters
                                #                                                                
                                grp_bellow_rel_ystep = NULL,
                                grp_bellow_rel_out = img.file(sprintf("gg_%s_bellow_rel.pdf", s)),
                                #
                                # Histogram parameters
                                #
                                hist_xmax = NULL, 
                                hist_xstep = NULL,
                                hist_ymax = NULL,
                                hist_ystep = NULL,                                
                                hist_ht = NULL, 
                                out_dir_hist = img.file(sprintf("scatdist/%s", s)),  
                                #
                                # Concentration parameters
                                #
                                conc_ystep = NULL, 
                                conc_ht = NULL, 
                                conc_out = img.file(sprintf("gg_%s_conc.pdf", s)),
                                #
                                # Gini parameters
                                #
                                gini_ystep = NULL, 
                                gini_ht = NULL,                                 
                                gini_out = img.file(sprintf("gg_%s_gini.pdf", s)),
                                #
                                # Other parameters
                                #
                                print_mcs = FALSE, 
                                print_summaries = FALSE,                                
                                out_dir_lc = img.file(sprintf("lc/%s", s)),
                                plot_frames = TRUE) {

  
  scat_subsystem <- subset(scat_drvs_distribution, subsystem == s)    
  
  # Gets the threshold of such scattering, while ploting the
  # scattering degree boxplot
  threshold <- plot_boxplot_sd(s, scat_subsystem, ystep = sd_ystep, 
                               ymax = max(scat_subsystem$total), ht = sd_ht, out = sd_out)$max
  
  cat("Threshold for ", s, ": ", threshold, "\n\n")
  
  # Plots the zoomed scattering degree boxplot to account for values
  # respecting the threshold
  invisible(plot_boxplot_sd(s, scat_subsystem, ymax = threshold,
                  ystep = sd_zoom_ystep, ht = sd_zoom_ht, out = sd_zoom_out))
  
  # Creates a threshold column in the scat_subsystem dataframe
  scat_subsystem$threshold <- classify_threshold(scat_subsystem$total, threshold)  
  
  # Obtaines a new dataframe containing two groups of scattered features;
  # the ones above the threshold, and those less than or equal to 
  # the threshold
  scat_subsystem_grps <- get_scat_threshold_groups(scat_subsystem)
  
  #. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .  
  # Plots and summarizes features above the threshold
  
  plot_subsystem_grp_scat(s, scat_subsystem_grps, threshold, above = TRUE, 
                          abs_ystep = grp_above_abs_ystep,
                          rel_ystep = grp_above_rel_ystep,
                          out_abs = grp_above_abs_out, out_rel = grp_above_rel_out)

  #. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .  
  # Plots and summarizes features bellow the threshold
  
  plot_subsystem_grp_scat(s, scat_subsystem_grps, threshold, above = FALSE,
                          abs_ystep = grp_bellow_abs_ystep,
                          rel_ystep = grp_bellow_rel_ystep,
                          out_abs = grp_bellow_abs_out, out_rel = grp_bellow_rel_out)  

  #. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  
  if  (plot_frames) {
    releases <- sqldf("select distinct release from scat_subsystem order by release")$release  
    
    gini <- c()
    gini <- plot_frames(s, releases, scat_subsystem,  threshold,
                hist_xmax = hist_xmax, hist_xstep = hist_xstep, 
                hist_ymax = hist_ymax, hist_ystep = hist_ystep, 
                hist_ht = hist_ht, 
                conc_ystep = conc_ystep, 
                conc_ht = conc_ht, 
                print_mcs = TRUE, summarize = TRUE,
                out_dir_hist = out_dir_hist,  
                out_dir_lc = out_dir_lc,  
                conc_out = conc_out,
                gini_ystep = gini_ystep, 
                gini_ht = gini_ht,                                               
                gini_out = gini_out)     
  }
  else 
    gini <- c()
  
  return(list(scat_subsystem_grps = scat_subsystem_grps,
              gini = gini))
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

classify_box_plot_position1 <- function(values, q2, q3, max_threshold) {  
  return(sapply(values, function (x) if (x <= q2) 
                                        sprintf("SD <= %d", q2)
                                      else if (x > q2 && x <= q3)
                                        sprintf("%d < SD <= %d", q2, q3)
                                      else if (x > q3 && x <= max_threshold)                                      
                                        sprintf("%d < SD <= %d", q3, max_threshold)
                                      else
                                        sprintf("SD > %d", max_threshold)))
}

classify_box_plot_position2 <- function(values, q2, q3, max_threshold) {  
  return(sapply(values, function (x) if (x <= q2) 
                                        "G1"
                                      else if (x > q2 && x <= q3)
                                        "G2"
                                      else if (x > q3 && x <= max_threshold)                                      
                                        "G3"
                                      else
                                        "G4"))
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

get_drvs_sd_global <- function() {
  res <- sqldf("select release, feature_name, sum(total) as total
               from   drvs_sd_per_subsystem
               group by release, feature_name
               order by release")
  return(res)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

get_count_drvs_sd_global <- function(drvs_sd_global, count_scat_drvs) {
  res <- sqldf("select release, 
               type, 
               grp,
               count(feature_name) as total,
               100 * count(feature_name) / (select total
                                            from  count_scat_drvs
                                            where count_scat_drvs.release = drvs_sd_global.release) as perc
       from drvs_sd_global
       group by release, type, grp
       order by release")
  return(res)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
# RQ3 stats

drvs_sd_per_subsystem <- get_scat_drvs_distribution()

drvs_sd_global <- get_drvs_sd_global()

count_scat_drvs <- get_count_scat_drvs()

sd_all <- plot_box_plot(xvals = drvs_sd_global$release, 
              yvals = drvs_sd_global$total,
              xlabel = "Release",
              ystep = 10,
              ht = 12,
              ylabel = "scattering degree",
              out = img.file("gg_sd_all.pdf"))


#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

outliers_top <- sd_all$outliers_top
colnames(outliers_top) <- c("release", "sd")

count_outliers <- sqldf("select release, count(*) from outliers_top group by release order by release")
count_outliers$perc <- 100.0 * count_outliers$count / count_scat_drvs$total

summarize_evol(amount = count_outliers$count,
               header = "Data points of highly scattered features", 
               type = "absolute")

plot_line(xvals = count_outliers$release, yvals = count_outliers$count, 
          xlabel = "Release", ylabel = "Nbr. of highly-\nscattered features", 
          out = img.file("gg_outliers_abs.pdf"))

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

non_outlier <- sd_all$non_outlier
outlier_fts <- sqldf("select distinct feature_name, avg(total) as avg, max(total) 
                      from non_outlier, drvs_sd_global 
                      where release = xv and drvs_sd_global.total >  non_outlier.top_whisker
                      group by feature_name
                      order by max desc, avg desc")
outlier_fts$latest_release <- get_feature_latest_release(outlier_fts$feature_name)

summarize_evol(amount = count_outliers$perc,
               header = "Data points of highly scattered features", 
               type = "relative")

plot_line(xvals = count_outliers$release, yvals = count_outliers$perc, 
        xlabel="Release", ylabel="Perc. of highly-\nscattered features",         
        ystep = 0.5,
        out = img.file("gg_outliers_rel.pdf"))

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

gini <- setNames(aggregate(total ~ release, data = drvs_sd_global, FUN=ineq), c("release", "gini"))
plot_line(xvals = gini$release, yvals = gini$gini, xlabel = "Release", ylabel = "Gini coefficient", out = img.file("gg_gini.pdf"))

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

scat_avg_pop <-
  sqldf("select sdglobal.feature_name as ft, 
                scatgrp.subsystem as subsys, 
                avg(sdglobal.total) as avg_sd 
        from drvs_sd_global as sdglobal, 
             scat_grps as scatgrp 
        where sdglobal.feature_name = scatgrp.feature_name
        group by sdglobal.feature_name, scatgrp.subsystem")

scat_avg_pop$only_driver <- scat_avg_pop$subsys == 'only driver'

scat_avg_pop$rank <- rank(scat_avg_pop$avg_sd, ties.method = "average")

cat("Avg scattering degree of features scattered only in driver")
summary(subset(scat_avg_pop, only_driver == TRUE)$avg_sd)

cat("Avg scattering degree of features scattered outside driver")
summary(subset(scat_avg_pop, only_driver == FALSE)$avg_sd)


# plot_box_plot(xvals = drvs_sd_global$release, 
#       yvals = drvs_sd_global$total,
#       xlabel = "Release",
#       ymax = 20,
#       ystep = 1,
#       ht = 12,
#       ylabel = "SD of scattered driver features",
#       out = img.file("gg_zoom_sd_all.pdf"))
# 
# drvs_sd_global$type = classify_box_plot_position1(values = drvs_sd_global$total, 
#                                                  q2 = median(sd_all$non_outliers$Q2),
#                                                  q3 = median(sd_all$non_outliers$Q3),
#                                                  max_threshold = median(sd_all$non_outliers$top_whisker))
# 
# drvs_sd_global$grp = classify_box_plot_position2(values = drvs_sd_global$total, 
#                                                   q2 = median(sd_all$non_outliers$Q2),
#                                                   q3 = median(sd_all$non_outliers$Q3),
#                                                   max_threshold = median(sd_all$non_outliers$top_whisker))
# 
# count_drvs_sd_global <- get_count_drvs_sd_global(drvs_sd_global, 
#                                                  count_scat_drvs)
# 
# plot_line(xvals = count_drvs_sd_global$release, 
#           yvals = count_drvs_sd_global$total,
#           xlabel = "Release",
#           ylabel = "Nbr. of scattered driver\nfeatures per threshold group",
#           ystep = 100,
#           discr = count_drvs_sd_global$type,
#           discrlabel = "Threshold group",
#           ht = 4,
#           out = img.file("gg_sd_abs.pdf"))
# 
# plot_line(xvals = count_drvs_sd_global$release, 
#           yvals = count_drvs_sd_global$perc,
#           xlabel = "Release",
#           ylabel = "Perc. of scattered driver\nfeatures per threshold group",
#           discr = count_drvs_sd_global$type,
#           ystep = 2,
#           ht = 4,
#           legend_position = "right",
#           discrlabel = "Threshold group",
#           out = img.file("gg_sd_rel.pdf"))  
# 
# sd_g1 <- subset(count_drvs_sd_global, grp == "G1")
# sd_g2 <- subset(count_drvs_sd_global, grp == "G2")
# sd_g3 <- subset(count_drvs_sd_global, grp == "G3")
# sd_g4 <- subset(count_drvs_sd_global, grp == "G4")
# 
# summarize_evol(amount = sd_g1$total, 
#                header = "Growth of G1",
#                type = "absolute",
#                rs = as.numeric(factor(sd_g1$release)))
# 
# summarize_evol(amount = sd_g2$total, 
#                header = "Growth of G2",
#                type = "absolute",
#                rs = as.numeric(factor(sd_g2$release)))
# 
# summarize_evol(amount = sd_g3$total, 
#                header = "Growth of G3",
#                type = "absolute",
#                rs = as.numeric(factor(sd_g3$release)))
# 
# 
# summarize_evol(amount = sd_g3$total, 
#                header = "Growth of G4",
#                type = "absolute",
#                rs = as.numeric(factor(sd_g4$release)))

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

# summarize_evol(amount = sd_g1$perc, 
#                header = "Growth of G1",
#                type = "relative",
#                rs = as.numeric(factor(sd_g1$release)))
# 
# summarize_evol(amount = sd_g2$perc, 
#                header = "Growth of G2",
#                type = "relative",
#                rs = as.numeric(factor(sd_g2$release)))
# 
# summarize_evol(amount = sd_g3$perc, 
#                header = "Growth of G3",
#                type = "relative",
#                rs = as.numeric(factor(sd_g3$release)))
# 
# 
# summarize_evol(amount = sd_g3$perc, 
#                header = "Growth of G4",
#                type = "relative",
#                rs = as.numeric(factor(sd_g4$release)))

# source("rq3_drivers.R")
# 
# source("rq3_arch.R")
# 
# source("rq3_core.R")
# 
# source("rq3_net.R")
# 
# source("rq3_fs.R")

