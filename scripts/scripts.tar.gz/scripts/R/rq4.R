require(exactRankTests)

scat_sample <- read.csv2(file=csv.file("scat_grps_sample_classified.csv"), 
                       sep=";", header=TRUE)

scat_sample$only_driver <- scat_sample$subsys == 'only driver'
scat_sample$is_plat     <- scat_sample$declares_platform_drv == 'TRUE'
scat_sample$is_infra    <- (scat_sample$ft_kind == 'INFR_CAP' | scat_sample$ft_kind == 'INFR_SUP')
scat_sample$is_sdev     <- (scat_sample$ft_kind == 'SDEV_SUP' | scat_sample$ft_kind == 'SDEV_CAP' | scat_sample$ft_kind == 'SDEV_PAR')
scat_sample$is_plat_or_infra <- scat_sample$is_plat | scat_sample$is_infra


cat("=============================================")

ctg_tbl1 <- table(scat_sample$is_infra, scat_sample$only_driver)
colnames(ctg_tbl1) <- c("not locally scat.", "locally scat.")
rownames(ctg_tbl1) <- c("not infra", "infra")
print(addmargins(ctg_tbl1))
print(chisq.test(ctg_tbl1, correct = FALSE))

cat("=============================================")

ctg_tbl2 <- table(scat_sample$is_plat, scat_sample$only_driver)
colnames(ctg_tbl2) <- c("not locally scat.", "locally scat.")
rownames(ctg_tbl2) <- c("not plat", "plat")
print(addmargins(ctg_tbl2))
print(chisq.test(ctg_tbl2, correct = FALSE))


#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

avg_scat_sample <- sqldf("select sd.feature_name as ft, 
                                 is_plat,
                                 is_infra,
                                 is_sdev,
                                 is_plat_or_infra,
                                 only_driver,
                                 avg(sd.total)   as avg_sd,
                                 max(sd.total)   as max
                          from drvs_sd_global as sd, 
                               scat_sample    as sample 
                          where sd.feature_name = sample.ft 
                          group by sd.feature_name, is_plat, is_infra, is_sdev, is_plat_or_infra, only_driver
                          order by avg_sd desc
                         ")

avg_scat_sample$scat   <- ifelse(avg_scat_sample$avg_sd <= 4, "Low", 
                                 ifelse(avg_scat_sample$avg_sd > 4 & avg_scat_sample$avg_sd <= 8, "Medium", "High"))

avg_scat_sample$plat           <- ifelse(avg_scat_sample$is_plat == TRUE,  "plat",  "not plat")
avg_scat_sample$infra          <- ifelse(avg_scat_sample$is_infra == TRUE, "Infrastructure", "Non-infrastructure")
avg_scat_sample$plat_or_infra  <- ifelse(avg_scat_sample$is_plat_or_infra, "plat_or_infra", "not_plat_or_infra")


scat_level_infra <- ggplot(avg_scat_sample, aes(x=factor(scat))) + geom_bar(colour="#FFFFFF") + gg_theme +  theme_bw(base_size = 18) +
  gg_theme + xlab("Scattering level") + ylab("Counting") + facet_grid(. ~ infra) 
ggsave(scat_level_infra, file = img.file("gg_scat_level_infra.pdf"), width=4.85, height=5.1)

  

avg_scat_sample$sdev   <- ifelse(avg_scat_sample$is_sdev == TRUE,  "sdev",  "not sdev")

wilcox.test(subset(avg_scat_sample, is_sdev == TRUE)$max, 
            subset(avg_scat_sample, is_sdev == FALSE)$max)

wilcox.test(subset(avg_scat_sample, is_infra == TRUE)$max, 
            subset(avg_scat_sample, is_infra == FALSE)$max)

wilcox.test(subset(avg_scat_sample, is_plat == TRUE)$max, 
            subset(avg_scat_sample, is_plat == FALSE)$max)


wilcox.test(subset(avg_scat_sample, is_sdev == TRUE)$avg_sd, 
            subset(avg_scat_sample, is_sdev == FALSE)$avg_sd)

wilcox.test(subset(avg_scat_sample, is_infra == TRUE)$avg_sd, 
            subset(avg_scat_sample, is_infra == FALSE)$avg_sd)

wilcox.test(subset(avg_scat_sample, is_plat == TRUE)$avg_sd, 
            subset(avg_scat_sample, is_plat == FALSE)$avg_sd)

wilcox.test(subset(avg_scat_sample, is_plat_or_infra == TRUE)$avg_sd, 
            subset(avg_scat_sample, is_plat_or_infra == FALSE)$avg_sd)

wilcox.test(subset(avg_scat_sample, is_plat_or_infra == TRUE)$max, 
            subset(avg_scat_sample, is_plat_or_infra == FALSE)$max)

avg_scat_sample_not_infra <- sqldf("select * from avg_scat_sample where is_infra = FALSE")

wilcox.exact(subset(avg_scat_sample_not_infra, is_plat == TRUE)$avg, 
            subset(avg_scat_sample_not_infra, is_plat == FALSE)$avg, alternative = "greater")

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .


avg_local_scat_sample <- subset(avg_scat_sample, only_driver == TRUE)


wilcox.test(subset(avg_local_scat_sample, is_sdev == TRUE)$avg_sd, 
            subset(avg_local_scat_sample, is_sdev == FALSE)$avg_sd)

wilcox.test(subset(avg_local_scat_sample, is_infra == TRUE)$avg_sd, 
            subset(avg_local_scat_sample, is_infra == FALSE)$avg_sd)

# ***Valid***
wilcox.test(subset(avg_local_scat_sample, is_plat == TRUE)$avg_sd, 
            subset(avg_local_scat_sample, is_plat == FALSE)$avg_sd)

wilcox.test(subset(avg_local_scat_sample, is_plat_or_infra == TRUE)$avg_sd, 
            subset(avg_local_scat_sample, is_plat_or_infra == FALSE)$avg_sd, alternative = "greater")

wilcox.test(subset(avg_local_scat_sample, is_plat_or_infra == TRUE)$max, 
            subset(avg_local_scat_sample, is_plat_or_infra == FALSE)$max, alternative = "greater")


#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

avg_ext_scat_sample <- subset(avg_scat_sample, only_driver == FALSE)

wilcox.exact(subset(avg_ext_scat_sample, is_sdev == TRUE)$avg_sd, 
            subset(avg_ext_scat_sample, is_sdev == FALSE)$avg_sd)

wilcox.exact(subset(avg_ext_scat_sample, is_infra == TRUE)$avg_sd, 
            subset(avg_ext_scat_sample, is_infra == FALSE)$avg_sd)

wilcox.exact(subset(avg_ext_scat_sample, is_plat == TRUE)$avg_sd, 
            subset(avg_ext_scat_sample, is_plat == FALSE)$avg_sd)

wilcox.exact(subset(avg_ext_scat_sample, is_plat_or_infra == TRUE)$avg_sd, 
            subset(avg_ext_scat_sample, is_plat_or_infra == FALSE)$avg_sd, alternative = "greater")

wilcox.exact(subset(avg_ext_scat_sample, is_plat_or_infra == TRUE)$max, 
             subset(avg_ext_scat_sample, is_plat_or_infra == FALSE)$max, alternative = "greater")


#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
#outliers

get_scat_location <- function(ft)
{
  subsys <-sqldf(sprintf("select subsystem
                         from scat_grps
                          where feature_name = '%s'", ft
                        )
                 )$subsystem ;
  return(subsys)
}

#write.table(outlier_fts, csv.file("outliers.csv"), quote = FALSE, sep = ";", row.names = FALSE, col.names = TRUE)

outliers_cl <- read.table(file=csv.file("outliers_classified.csv"), 
                         sep=";", header=TRUE, 
                         colClasses=c("character","double","double","character","character","character","character","character","character","character","character","logical"))

outliers_cl$subsys <- mapply(get_scat_location, outliers_cl$feature_name) 
outliers_cl$is_infra    <- (outliers_cl$ft_kind == 'INFR_CAP' | outliers_cl$ft_kind == 'INFR_SUP')
outliers_cl$is_sdev     <- (outliers_cl$ft_kind == 'SDEV_SUP' | outliers_cl$ft_kind == 'SDEV_CAP' | outliers_cl$ft_kind == 'SDEV_PAR')
outliers_cl$is_plat     <- (outliers_cl$declares_platform_drv == TRUE)
outliers_cl$location    <- ifelse(outliers_cl$subsys == 'only driver',  "Local",  "External")
outliers_cl$rank_max <- rank(outliers_cl$max)
outliers_cl$rank_avg <- rank(outliers_cl$max)
outliers_cl$plat     <- ifelse(outliers_cl$declares_platform_drv == TRUE,  "Platform",  "Non-platform")

# . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

outliers_infra <- ggplot(outliers_cl, aes(x=factor(rank_avg), fill=is_infra)) + geom_bar(width = .5, colour="#FFFFFF") + gg_theme + 
  xlab("Rank of average SD values") + theme_bw(base_size = 18) + theme(axis.text.x = element_text(angle = 90, hjust = 1)) + ylab("Nbr. of outlier features") +
  theme(legend.position="top") + theme(legend.title=element_blank()) + scale_fill_discrete(name="",
                                                                                           breaks=c(TRUE, FALSE),
                                                                                           labels=c("Infrastructure", "Non-infrastructure"))
ggsave(outliers_infra, file = img.file("gg_outliers_infra.pdf"), height=8.5)

# . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

outliers_non_infra <- ggplot(subset(outliers_cl, is_infra == FALSE), aes(x=factor(rank_avg), fill=is_plat)) + geom_bar(width = .5, colour="#FFFFFF") + gg_theme + 
  xlab("Rank of average SD values") + theme_bw(base_size = 18) + theme(axis.text.x = element_text(angle = 90, hjust = 1)) + ylab("Nbr. of outlier features") +
  theme(legend.position="top") + theme(legend.title=element_blank()) + scale_fill_discrete(name="",
                                                                                           breaks=c(TRUE, FALSE),
                                                                                           labels=c("Platform", "Non-platform"))
ggsave(outliers_non_infra, file = img.file("gg_outliers_non_infra.pdf"), height=8.5)

# . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

outliers_plat <- ggplot(outliers_cl, aes(x=factor(rank_avg), fill=)) + geom_bar(width = .5, colour="#FFFFFF") + facet_grid(location ~ .) + gg_theme + 
  xlab("Rank of average SD values") + theme_bw(base_size = 18.5) + theme(axis.text.x = element_text(angle = 90, hjust = 1)) + ylab("Counting") +
  theme(legend.position="top") + theme(legend.title=element_blank())



