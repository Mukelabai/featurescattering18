#!/usr/bin/Rscript

get_drv_count_per_arch_type <- function() {
  res <-  dbGetQuery(conn,
     "(select release, 
              'PC-like/mainframe'::text as type,
              count(distinct feature_name) as total
      from allyes_config ays
      where exists(select *
                   from uniq_drvs, release
                   where ('CONFIG_' || uniq_drvs.feature_name) = ays.feature_name and
                         uniq_drvs.release_id = release.id and
                         release.name = ays.release) and
                         architecture in 
                        ('alpha', 'i386', 'ia64', 'powerpc', 'ppc', 'ppc64', 's390', 'sparc', 'sparc64', 'x86', 'x86_64')
      group by release
     )
     
     union
     
     (select release, 
             'Others'::text as type,
            count(distinct feature_name) as total
      from allyes_config ays
      where exists(select *
                   from uniq_drvs, release
                   where ('CONFIG_' || uniq_drvs.feature_name) = ays.feature_name and
                         uniq_drvs.release_id = release.id and
                         release.name = ays.release) and
                         architecture not in 
                         ('alpha', 'i386', 'ia64', 'powerpc', 'ppc', 'ppc64', 's390', 'sparc', 'sparc64', 'x86', 'x86_64')
     group by release)        
     order by release"
  )
  return(res)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

get_count_scat_drvs_per_arch_type <- function() {
  res <- dbGetQuery(conn,
    "with drvs_in_general as (
      select distinct release, feature_name
      from allyes_config ays
      where exists(select *
                     from uniq_drvs, release
                   where ('CONFIG_' || uniq_drvs.feature_name) = ays.feature_name and
                   uniq_drvs.release_id = release.id and
                   release.name = ays.release) and
      architecture in ('alpha', 'i386', 'ia64', 'powerpc', 'ppc', 'ppc64', 's390', 'sparc', 'sparc64', 'x86', 'x86_64')
    ),
    
    count_scat_drvs_in_general as (
      select release, count(feature_name) as total
      from drvs_in_general as gen_drvs
      where exists(select *
                     from scat_drvs_ifdef_refs as refs
                   where ('CONFIG_' || refs.feature_name) = gen_drvs.feature_name and
                   refs.release = gen_drvs.release and 
                   (refs.file_path like 'arch/alpha/%'    or
                    refs.file_path like 'arch/i386/%'     or
                    refs.file_path like 'arch/ia64/%'     or
                    refs.file_path like 'arch/powerpc/%'  or
                    refs.file_path like 'arch/ppc/%'      or
                    refs.file_path like 'arch/ppc64/%'    or
                    refs.file_path like 'arch/s390/%'     or
                    refs.file_path like 'arch/sparc/%'    or
                    refs.file_path like 'arch/sparc64/%'  or
                    refs.file_path like 'arch/x86/%'      or
                    refs.file_path like 'arch/x86_64/%')
      )
      group by release			   
    ),
    
    drvs_in_restricted as (
      select distinct release, feature_name
      from allyes_config ays
      where exists(select *
                     from uniq_drvs, release
                   where ('CONFIG_' || uniq_drvs.feature_name) = ays.feature_name and
                   uniq_drvs.release_id = release.id and
                   release.name = ays.release) and
      architecture not in ('alpha', 'i386', 'ia64', 'powerpc', 'ppc', 'ppc64', 's390', 'sparc', 'sparc64', 'x86', 'x86_64')
    ),
    
    count_scat_drvs_in_restricted as (
      select release, count(feature_name) as total
      from drvs_in_restricted 
      where exists(select *
                     from scat_drvs_ifdef_refs as refs
                   where ('CONFIG_' || refs.feature_name) = drvs_in_restricted.feature_name and
                   refs.release = drvs_in_restricted.release and 
                   (refs.file_path like 'arch/arc/%'        or
                    refs.file_path like 'arch/arm/%'        or
                    refs.file_path like 'arch/arm26/%'      or
                    refs.file_path like 'arch/arm64/%'      or
                    refs.file_path like 'arch/avr32/%'      or
                    refs.file_path like 'arch/blackfin/%'   or
                    refs.file_path like 'arch/c6x/%'        or
                    refs.file_path like 'arch/cris/%'       or
                    refs.file_path like 'arch/frv/%'        or
                    refs.file_path like 'arch/h8300/%'      or
                    refs.file_path like 'arch/hexagon/%'    or
                    refs.file_path like 'arch/m32r/%'       or
                    refs.file_path like 'arch/m68k/%'       or
                    refs.file_path like 'arch/m68knommu/%'  or
                    refs.file_path like 'arch/metag/%'      or
                    refs.file_path like 'arch/microblaze/%' or
                    refs.file_path like 'arch/mips/%'       or
                    refs.file_path like 'arch/mn10300/%'    or
                    refs.file_path like 'arch/openrisc/%'   or
                    refs.file_path like 'arch/parisc/%'     or     
                    refs.file_path like 'arch/score/%'      or
                    refs.file_path like 'arch/sh/%'         or
                    refs.file_path like 'arch/sh64/%'       or
                    refs.file_path like 'arch/tile/%'       or
                    refs.file_path like 'arch/um/%'         or
                    refs.file_path like 'arch/unicore32/%'  or
                    refs.file_path like 'arch/v850/%'       or
                    refs.file_path like 'arch/xtensa/%')
      )
      
      group by release			   
    )
    
    (select release, 
     'PC-like/mainframe'::text as type,
     count_scat_gen.total, 
     100.0 * count_scat_gen.total / (select count(distinct feature_name) 
                                     from  drvs_in_general 
                                     where drvs_in_general.release = count_scat_gen.release) as perc
     from count_scat_drvs_in_general as count_scat_gen)
    
    union
    
    (select release, 
     'Others'::text as type,
     count_scat_restricted.total, 
     100.0 * count_scat_restricted.total / (select count(distinct feature_name) 
                                            from  drvs_in_restricted 
                                            where drvs_in_restricted.release = count_scat_restricted.release) as perc
     from count_scat_drvs_in_restricted as count_scat_restricted)
    
    order by release"
  )
  
  return(res)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

count_drvs_per_arch_type <- get_drv_count_per_arch_type()

plot_line(xvals = count_drvs_per_arch_type$release, 
          yvals = count_drvs_per_arch_type$total,
          xlabel = "Release",
          ylabel = "Nbr. of driver features\n(allyes config)",
          discr = count_drvs_per_arch_type$type,
          discrlabel = "Architecture type", 
          ymax = 6000,
          ystep = 400,
          ht = 4, out = img.file("gg_drvs_per_arch_type.pdf"))

count_scat_drvs_per_arch_type <- get_count_scat_drvs_per_arch_type()

plot_line(xvals = count_scat_drvs_per_arch_type$release, 
          yvals = count_scat_drvs_per_arch_type$total,
          xlabel = "Release",
          ylabel = "Nbr. of scattered driver features\n(allyes config)",
          discr = count_scat_drvs_per_arch_type$type,
          discrlabel = "Architecture type", 
          ymax = 400,
          ystep = 50,
          ht = 4, out = img.file("gg_drvs_per_arch_type_abs.pdf"))

plot_line(xvals = count_scat_drvs_per_arch_type$release, 
          yvals = count_scat_drvs_per_arch_type$perc,
          xlabel = "Release",
          ylabel = "Perc. of scattered driver features\nfrom allyes config (per architecture type)",
          discr = count_scat_drvs_per_arch_type$type,
          discrlabel = "Architecture type", 
          ymax = 6,
          ystep = 0.5,
          ht = 4, out = img.file("gg_drvs_per_arch_type_rel.pdf"))