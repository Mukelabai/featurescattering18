#!/usr/bin/Rscript

get_count_scat_inout_driver <- function() {
  
  count_scat_inout_driver <- dbGetQuery(conn,
    "with local_scat as (
      select distinct release_id,
                      feature_name
      
      from   scat_drvs_ifdef_refs as refs1
      
      where refs1.subsystem = 'driver' and
            not exists (select *
                        from scat_drvs_ifdef_refs as refs2
                        where refs1.release_id = refs2.release_id and
                              refs1.feature_name = refs2.feature_name and
                              refs1.subsystem <> refs2.subsystem
      )
    ),
    
    external_scat as (
      select distinct release_id,
                      feature_name
      
      from scat_drvs_ifdef_refs as refs1
      
      where not exists (select *
                        from local_scat as refs2
                        where refs1.release_id = refs2.release_id and
                              refs1.feature_name = refs2.feature_name
      )
    )
    
    (select release.name as release,
            'Locally scattered driver features'::text as type,
            count(*) as total
    
     from local_scat, release
    
     where local_scat.release_id = release.id
    
     group by release.name, type
    )
    
    union
    
    (select release.name as release,
           'Externally scattered driver features'::text as type,
           count(*) as total
    
     from external_scat, release
    
     where external_scat.release_id = release.id
    
     group by release.name, type
    )
    
    order by release, type"
  )  
  
  return(count_scat_inout_driver)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

get_count_scat_drvs_out_per_subsystem <- function(external_total) {
  count_scat_drvs_out_per_subsystem <- dbGetQuery(conn, 
     "select release,
            subsystem,
            count(distinct feature_name) as total
    
     from scat_drvs_ifdef_refs

     where subsystem <> 'driver'
    
     group by release_id, release, subsystem"
  )
  
  count_scat_drvs_out_per_subsystem <-
    sqldf("select release,
                subsystem,
                total,
                (100.0 * total / (select total 
                                  from external_total 
                                  where external_total.release = 
                                        count_scat_drvs_out_per_subsystem.release)) as perc
          from count_scat_drvs_out_per_subsystem")
  
  return(count_scat_drvs_out_per_subsystem)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

count_intersect <- function(df1, df2) {
  return(sqldf("with common as 
                ((select * from df1) 
                 intersect 
                 (select * from df2))
                select release, count(distinct feature_name) as total
                from   common
                group by release
                order by release")
         )
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

get_count_interset_scat_drvs_out <- function(sn, sd) {
    
  s1 <- get_scat_drvs(sn)
  s2 <- get_scat_drvs(sd)
  
  intersect <- count_intersect(s1, s2)
  intersect$type <- paste(sd, " -> ", sn, sep="")
  intersect$perc <- 100 * intersect$total / nrow(s2)
  
  return(intersect)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

get_count_interset_scat_drvs_out_from_list <- function(subsystem_pairs) {
  
  res <- data.frame(release = c(), type = c(), perc = c())
  
  for(substystem_pair in subsystem_pairs) {
    s1 <- substystem_pair[1]  
    s2 <- substystem_pair[2]  
    
    res <- rbind(res, get_count_interset_scat_drvs_out(s1, s2)) 
  }

  return(res)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

dup <- function(list, times = 1) {
  if (length(list) == 0) return(c())
  if (length(list) == 1) return(c(list[1], list[1]))
  return(c(c(rep(list[1], times), list[1]), dup(list[2:length(list)])))
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

get_scat_pop <- function(subsystems) {
  
  res <- data.frame(feature_name = c(), subsystem = c())
  for(n in 1:length(subsystems)) {
    
    combs <- combn(subsystems, n)            
    
    for(col in 1:ncol(combs)) {
      
      in_query <- "("
      in_subsystems <- combs[, col]
      union <- c(rep(" intersect ", length(in_subsystems) - 1), "")
      
      for(s in 1:length(in_subsystems)) {
        in_query <- paste(in_query, "\n",
                          sprintf(" (select distinct feature_name from scat_drvs_ifdef_refs where subsystem = '%s')", 
                                  in_subsystems[s]), union[s], sep="")
      }
      in_query <- paste(in_query, "\n)", sep="")
      
      notin_query <- "("
      complement <- subsystems [! subsystems %in% combs[,col]]
      
      if (length(complement) == 0)
        next 
      
      union <- c(rep(" union ", length(complement) - 1), "")
      
      for(s in 1:length(complement)) {
        
        notin_query <- paste(notin_query, "\n",
                             sprintf(" (select distinct feature_name from scat_drvs_ifdef_refs where subsystem = '%s')", 
                                     complement[s]), union[s], sep="")
      }
      notin_query <- paste(notin_query, "\n)", sep="")      
      
      if (debug)
        cat(sprintf("%s except %s", in_query, notin_query), "\n\n")
      
      comb_res <- dbGetQuery(conn, sprintf("%s except %s", in_query, notin_query))
      
      if (length(in_subsystems) > 1)
        comb_res$subsystem <- rep(paste(in_subsystems, collapse=" & "), nrow(comb_res))
      else
        comb_res$subsystem <- paste("only ", in_subsystems[1], sep="")
      
      res <- rbind(res, comb_res)
    }    
  }
  return(res)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . .undebu() . . . . . . . . . . . . . .

regrp_scat_pop <- function(subsystems, scat_pop) {  
  
  if(debug)
    cat("select feature_name, subsystem from scat_pop where subsystem = 'only driver'", "\n")
  
  # Initializes the result by filtering driver features scattered across driver only
  res <- sqldf("select feature_name, subsystem from scat_pop where subsystem = 'only driver'")
  
  # Regroups all subsystems except drivers
  # Regrouping takes the intersection of the input subsytem and driver, 
  # and unifies with the features inside the subsystem only
  # Example: if the subsystem is arch, then we take arch + (arch & driver)
  
  for(s in subsystems[! subsystems == "driver"] ) {
          
    new_subsystem <- paste(s, " + (", s, " & driver)", sep="")
    
    intersect <- if (s < "driver") 
      sprintf("%s & driver", s)
    else
      sprintf("driver & %s", s)
        
    if (debug) {
      cat(sprintf("select feature_name from scat_pop where subsystem = 'only %s' or subsystem = '%s'", 
                  s, intersect), "\n")
    }
    
    rgrp <- sqldf(sprintf("select feature_name
                               from scat_pop
                               where subsystem = 'only %s' or subsystem = '%s'", 
                               s, intersect))
    rgrp$subsystem <- new_subsystem
    res <- rbind(res, rgrp)
  }
  
  if (debug)
    cat("(select feature_name from res) except (select feature_name from scat_pop)", "\n")
  
  others <- sqldf("(select feature_name from scat_pop) 
                    except 
                   (select feature_name from res)")  
  others$subsystem <- "others"  
  res <- rbind(res, others)
  
  return(res)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

get_count_scat_pop <- function(scat_pop) {  
  count <- sqldf("select subsystem, count(feature_name) as total from scat_pop group by subsystem")
  return(count)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

get_feature_latest_release <- function(features) {
  res <- c()
  for(feature in features) {
      release <- dbGetQuery(conn, sprintf("select distinct release
                                           from scat_drvs_ifdef_refs
                                           where feature_name = '%s'
                                           order by release desc
                                           limit 1", feature))$release
      res <- c(res, release)
  }
  return(res)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

count_scat_drvs_inout <- get_count_scat_inout_driver()
count_scat_drvs_inout$perc <- 100 * count_scat_drvs_inout$total / dup(count_scat_drvs$total)

plot_line(xvals = count_scat_drvs_inout$release, 
          yvals = count_scat_drvs_inout$total,
          xlabel = "Release",
          ylabel = paste("Nbr. of scattered-\ndriver features"),
          discr = count_scat_drvs_inout$type,
          discrlabel = "Type", 
          out = img.file("gg_inout_drvs_abs.pdf"))

count_scat_drvs_in  <- subset(count_scat_drvs_inout, type == 'Locally scattered driver features')
count_scat_drvs_out <- subset(count_scat_drvs_inout, type == 'Externally scattered driver features')

summarize_evol(amount = count_scat_drvs_in$total,
               header = "Data points of locally scattered driver features",
               type = "absolute")

summarize_evol(amount = count_scat_drvs_out$total,
               header = "Data points externally scattered driver features",
               type = "absolute")

print_header("Growth (%) of the nbr of locally scattered driver features")
print_summary(get_growth(count_scat_drvs_in$total), perc = TRUE)

print_header("Growth (%) of the nbr of externally scattered driver features")
print_summary(get_growth(count_scat_drvs_out$total), perc = TRUE)


plot_line(xvals = count_scat_drvs_inout$release, 
          yvals = count_scat_drvs_inout$perc,
          xlabel = "Release",
          ylabel = paste("Perc. of scattered-\ndriver features"),
          discr = count_scat_drvs_inout$type,
          discrlabel = "Type", 
          out = img.file("gg_inout_drvs_rel.pdf"))

summarize_evol(amount = count_scat_drvs_in$perc,
               header = "Data points of locally scattered driver features",
               type = "relative")

summarize_evol(amount = count_scat_drvs_out$perc,
               header = "Data points of externally scattered driver features",
               type = "relative")

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
# External scattering (absolute)

count_scat_drvs_out_per_subsystem <- 
  get_count_scat_drvs_out_per_subsystem(count_scat_drvs_out)

plot_line(xvals = count_scat_drvs_out_per_subsystem$release, 
          yvals = count_scat_drvs_out_per_subsystem$total,
          xlabel = "Release",
          ylabel = paste("Nbr. of scattered-\ndriver features"),
          discr = count_scat_drvs_out_per_subsystem$subsystem,
          discrlabel = "Subsystem", 
          ymax = 300,
          ystep = 50,
          ht = 4.5, out = img.file("gg_scat_drvs_out_per_sub_abs.pdf"))

summarize_evol(amount = subset(count_scat_drvs_out_per_subsystem, subsystem == 'arch')$total,
               header = "Data points of externally scattered driver features in arch",
               type = "absolute")

summarize_evol(amount = subset(count_scat_drvs_out_per_subsystem, subsystem == 'core')$total,
               header = "Data points of externally scattered driver features in core",
               type = "absolute")

summarize_evol(amount = subset(count_scat_drvs_out_per_subsystem, subsystem == 'fs')$total,
               header = "Data points of externally scattered driver features in fs",
               type = "absolute")

summarize_evol(amount = subset(count_scat_drvs_out_per_subsystem, subsystem == 'net')$total,
               header = "Data points of externally scattered driver features in net",
               type = "absolute")

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
# Relative growth (relative)

plot_line(xvals = count_scat_drvs_out_per_subsystem$release, 
          yvals = count_scat_drvs_out_per_subsystem$perc,
          xlabel = "Release",
          ylabel = paste("Perc. of scattered-\ndriver features"),
          discr = count_scat_drvs_out_per_subsystem$subsystem,
          discrlabel = "Subsystem", 
          ymax = 100,
          ystep = 20,
          ht = 4.5, out = img.file("gg_scat_drvs_out_per_sub_rel.pdf"))

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

count_interset_scat_drvs_out <-
  get_count_interset_scat_drvs_out_from_list(list(
    c("net", "fs"),
    c("core", "fs"),
    c("arch", "fs"),
    c("core", "net"),
    c("arch", "net"),
    c("arch", "core")
  ))

plot_line(xvals = count_interset_scat_drvs_out$release, 
          yvals = count_interset_scat_drvs_out$total,
          xlabel = "Release",
          ylabel = paste("Nbr. of common externally-\nscattered-driver features"),
          discr = count_interset_scat_drvs_out$type,
          discrlabel = "Overlapping", 
          legend_position = "right",
          ymax = 70,
          ystep = 5,
          ht = 4.5, out = img.file("gg_scat_drvs_out_common_abs.pdf"))

plot_line(xvals = count_interset_scat_drvs_out$release, 
          yvals = count_interset_scat_drvs_out$perc,
          xlabel = "Release",
          ylabel = paste("Perc. of common externally-\nscattered-driver features"),
          discr = count_interset_scat_drvs_out$type,
          discrlabel = "Overlapping", 
          legend_position = "right",
          ymax = 4,
          ystep = 0.2,
          ht = 4.5, out = img.file("gg_scat_drvs_out_common_rel.pdf"))

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

scat_pop <- get_scat_pop(subsystems = c("arch", "core", "driver", "fs", "net"))

count_scat_pop <- get_count_scat_pop(scat_pop)
plot_barchart(xvals = count_scat_pop$subsystem, 
              yvals = count_scat_pop$total,
              xlabel = "Scattered subsystems",
              ylabel = "Nbr. of unique\ndriver features",
              ystep = 100,
              ht = 6.5,
              out = img.file("gg_scat_grps.pdf"))

scat_grps <- regrp_scat_pop(subsystems = c("arch", "core", "driver"), 
                            scat_pop)

#scat_sample <- gen_sample(pop = scat_grps, sample_size = ceiling(0.10 * nrow(scat_grps)))

#scat_sample$latest_release <- 
#  get_feature_latest_release(scat_sample$feature_name)

#write.table(scat_sample, 
#            csv.file("scat_grps_sample.csv"), 
#            quote = FALSE, 
#            sep = ";", 
#            row.names = FALSE, 
#            col.names = TRUE)

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

