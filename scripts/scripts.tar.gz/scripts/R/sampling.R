#!/usr/bin/Rscript

get_scat_only_in_subsystem_pop <- function(s) {
  res <- dbGetQuery(conn, sprintf(
             "select distinct refs1.feature_name as feature,
                              release.name       as release

              from scat_drvs_ifdef_refs as refs1, 
                  release

              where refs1.subsystem = '%s' and 
                    not exists (select *
                                from scat_drvs_ifdef_refs as refs2
                                where refs2.release_id = refs1.release_id and
                                      refs2.feature_name = refs1.feature_name and
                                      refs2.subsystem <> refs1.subsystem) and
                    refs1.release_id = release.id

             order by feature, release", s))
  return(res)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

get_non_scat_pop <- function() {
  res <- dbGetQuery(conn,
            "select distinct uniq.feature_name as feature,
                             release.name      as release

            from uniq_drvs as uniq, 
                release
            
            where not exists(select *
                               from  scat_drvs_ifdef_refs as refs
                             where refs.release_id = uniq.release_id and
                             refs.feature_name = uniq.feature_name
            ) and
            uniq.release_id = release.id
            
            order by feature, release"
  )
  return(res)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

count_distinct_features <- function(fts) {
  res <- sqldf("select distinct feature
                from fts")
  return(res)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

sample_size = 0.01

scat_in_driver_only_pop <- get_scat_only_in_subsystem_pop('driver')
cat("Population size (driver only): ", nrow(count_distinct_features(scat_in_driver_only_pop)), "\n\n")
cat("Sample size (driver only): ", sample_size * nrow(count_distinct_features(scat_in_driver_only_pop)), "\n\n")
write.csv(scat_in_driver_only_pop, file="/home/leonardo/Desktop/pops/driver_only_pop.csv", row.names = FALSE)

scat_in_arch_only_pop <- get_scat_only_in_subsystem_pop('arch')
cat("Population size (arch only): ", nrow(count_distinct_features(scat_in_arch_only_pop)), "\n\n")
cat("Sample size (arch only): ", sample_size * nrow(count_distinct_features(scat_in_arch_only_pop)), "\n\n")
write.csv(scat_in_arch_only_pop, file="/home/leonardo/Desktop/pops/arch_only_pop.csv", row.names = FALSE)

scat_in_core_only_pop <- get_scat_only_in_subsystem_pop('core')
cat("Population size (core only): ", nrow(count_distinct_features(scat_in_core_only_pop)), "\n\n")
cat("Sample size (core only): ", sample_size * nrow(count_distinct_features(scat_in_core_only_pop)), "\n\n")
write.csv(scat_in_core_only_pop, file="/home/leonardo/Desktop/pops/core_only_pop.csv", row.names = FALSE)

scat_in_fs_only_pop <- get_scat_only_in_subsystem_pop('fs')
cat("Population size (fs only): ", nrow(count_distinct_features(scat_in_fs_only_pop)), "\n\n")
cat("Sample size (fs only): ", sample_size * nrow(count_distinct_features(scat_in_fs_only_pop)), "\n\n")
write.csv(scat_in_fs_only_pop, file="/home/leonardo/Desktop/pops/fs_only_pop.csv", row.names = FALSE)

scat_in_net_only_pop <- get_scat_only_in_subsystem_pop('net')
cat("Population size (net only): ", nrow(count_distinct_features(scat_in_net_only_pop)), "\n\n")
cat("Sample size (net only): ", sample_size * nrow(count_distinct_features(scat_in_net_only_pop)), "\n\n")
write.csv(scat_in_net_only_pop, file="/home/leonardo/Desktop/pops/net_only_pop.csv", row.names = FALSE)

non_scat <- get_non_scat_pop()
cat("Population size (non scat): ", nrow(count_distinct_features(non_scat)), "\n\n")
cat("Sample size (non scat): ", sample_size * nrow(count_distinct_features(non_scat)), "\n\n")
write.csv(scat_in_net_only_pop, file="/home/leonardo/Desktop/pops/net_only_pop.csv", row.names = FALSE)
