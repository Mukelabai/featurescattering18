#!/usr/bin/Rscript

# Gets the scattering inside arch

fs_scat_threshold_grps <- plot_subsystem_scat('fs', 
                    drvs_sd_per_subsystem ,
                    sd_ystep = 1,                      
                    sd_zoom_ystep = 2,
                    grp_above_abs_ystep = 0.05,
                    grp_above_rel_ystep = 0.05,
                    grp_bellow_abs_ystep = 1,
                    grp_bellow_rel_ystep = 0.05,
                    hist_xmax = 150, 
                    hist_xstep = 10,
                    hist_ymax = 110,
                    hist_ystep = 10,                                
                    conc_ystep = 5,
                    gini_ystep = 0.05,
                    plot_frames = FALSE)

fs_scat_threshold_grps$scat_subsystem_grps$subsystem = 'fs'

