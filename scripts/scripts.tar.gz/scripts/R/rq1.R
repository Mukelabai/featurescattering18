#!/usr/bin/Rscript

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

get_count_scat_drvs <- function() {
  count_scat_drvs <- dbGetQuery(conn, 
    "select release.name as release,
            count(distinct feature_name) as total

    from scat_drvs, release
    
    where scat_drvs.release_id = release.id
    
    group by release.name"
  )
  return(count_scat_drvs)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

summarize_scat_evol <- function(s, count_scat_drvs_per_subsystem, rel=FALSE, 
                            header = sprintf("Scattering growth in %s", s, type)) {  
  
  count_scat_drvs_in_s <- subset(count_scat_drvs_per_subsystem, subsystem == s)
  
  amount <- 
    if (rel) {      
      type <- "relative"
      count_scat_drvs_in_s$perc
    }
  else {
    type <- "absolute"    
    count_scat_drvs_in_s$total    
  }  
  summarize_evol(amount = count_scat_drvs_in_s$total, header, type)  
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

summarize_evol <- function(amount, header, type, rs = seq_releases) {
  print_header(sprintf("%s (%s):", header, type))
  print_summary(amount)
  if (type == "absolute")
    print_rel_diff(amount)
  else  
    print_diff(amount)  
  cat("SLOPE.......: ", get_lm_slope(amount, rs), 
      "\n\n")  
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
# RQ1 stats

count_uniq_drvs <- get_count_all_uniq_drvs()
count_scat_drvs <- get_count_scat_drvs()

count_scat_drvs$perc <- 100.0 * count_scat_drvs$total / count_uniq_drvs$total
count_scat_drvs$type <- 'Scattered driver features' 

count_non_scat_drvs <- data.frame(
  release = count_scat_drvs$release,
  total = count_uniq_drvs$total - count_scat_drvs$total,
  perc  = 100.0 * (count_uniq_drvs$total - count_scat_drvs$total) / count_uniq_drvs$total,
  type = 'Non-scattered driver features'
) 

growth_drvs <- rbind(count_scat_drvs, count_non_scat_drvs)

plot_line(xvals = growth_drvs$release, 
          yvals = growth_drvs$total,
          discr = growth_drvs$type,
          discrlabel = "Type",
          xlabel = "Release",
          ylabel = "Nbr. of scattered\ndriver features",
          ymax = 7000,
          ystep = 1000,
          ht = 3.5, out = img.file("gg_scat_drvs_abs.pdf"))

summarize_evol(amount = count_scat_drvs$total,
               header = "Data points of scattered driver features", 
               type = "absolute")

summarize_evol(amount = count_non_scat_drvs$total,
               header = "Data points of non-scattered drivers", 
               type = "absolute")

print_header("Growth (%) of the nbr of scattered driver features")
print_summary(get_growth(count_scat_drvs$total), perc = TRUE)

print_header("Growth (%) of the nbr of non-scattered driver features")
print_summary(get_growth(count_non_scat_drvs$total), perc = TRUE)

plot_line(xvals = growth_drvs$release, 
          yvals = growth_drvs$perc,
          discr = growth_drvs$type,
          discrlabel = "Type",
          xlabel = "Release",
          ymax = 100,
          ystep = 10,
          ylabel = "Perc. of scattered\ndriver features",
          ht = 3.5, out = img.file("gg_scat_drvs_rel.pdf"))

summarize_evol(amount = count_scat_drvs$perc,
               header = "Data points of scattered driver features", 
               type = "relative")

summarize_evol(amount = count_non_scat_drvs$perc,
               header = "Data points of non-scattered driver features", 
               type = "relative")

