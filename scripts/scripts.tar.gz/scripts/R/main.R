#!/usr/bin/Rscript

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
# Global settings (1)

base_dir <- "/home/leonardo/workspace/modularity2015/scripts/R/"

setwd(base_dir)

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
# Common functions

source("common.R")
source("plot.R")

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
# Global settings (2)

show_plot <- TRUE
debug     <- TRUE

connect_db()

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

source("general.R")

source("rq1.R")
source("rq2.R")

source("rq3.R")
source("rq4.R")

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

disconnect_db()
