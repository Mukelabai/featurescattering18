#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

get_scat_drvs_location_out <- function() {

   scat_drvs_location_out <- dbGetQuery(conn,  
      "select distinct uniq_drvs.feature_name as feature_name,
                      subsystem.name          as subsystem,
                      ((select dentries[1] 
                       from string_to_array(file_info.path, '/') as dentries
                       where array_length(dentries, 1) = 2)
                       union
                       (select dentries[1] || '/' || dentries[2]
                       from string_to_array(file_info.path, '/') as dentries
                       where array_length(dentries, 1) = 3)
                       union
                       (select dentries[1] || '/' || dentries[2] || '/' || dentries[3]
                       from string_to_array(file_info.path, '/') as dentries
                       where array_length(dentries, 1) >= 4)                       
                      ) as dir, 
                      (select name 
                       from release 
                       where uniq_drvs.release_id = release.id) as release

      from filtered_ifdef_refs, uniq_drvs, file, file_info, subsystem

      where filtered_ifdef_refs.feature_name = uniq_drvs.feature_name and
            filtered_ifdef_refs.fk_c_source_file = file.id and
            file.fk_file_info = file_info.id and
            file.fk_release = uniq_drvs.release_id and
            file_info.fk_subsystem = subsystem.id and
            subsystem.name <> 'driver'"
   )
   
   return(scat_drvs_location_out)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

plot_zoom_scat <- function(scat_drvs_location_out_data, scat_out,
                           max_rows = 20, release = "",
                           subsystem = "", out_abs, out_rel) {                                                              

#  grouped_scat_drvs_out <- sqldf(
#    "with count_scat_drvs_location_out as 
#         (select  subsystem, 
#                  dir,           
#                  count(feature_name) as total,
#                  (select 100.0 * count(feature_name) / scat_out.total
#                   from   scat_out
#                   where  scat_out.release    in (select * from rel) and 
#                          scat_out.subsystem  in (select * from sub) 
#                  ) as perc     
#          from    scat_drvs_location_out_data
#          where   release   in (select * from rel) and
#                  subsystem in (select * from sub)
#          group by subsystem, dir
#        ) 
#     select *
#     from   count_scat_drvs_location_out
#     where  perc >= (select perc from threshold)
#     order by perc desc"
#  )
  
  
  grouped_scat_drvs_out <- sqldf(sprintf(
    "with count_scat_drvs_location_out as 
         (select  dir,           
                  (select 100.0 * count(feature_name) / scat_out.total
                   from   scat_out
                   where  scat_out.subsystem  = '%s' and 
                          scat_out.release = '%s'
                  ) as perc
          from    scat_drvs_location_out_data
          where   subsystem = '%s' and release = '%s'
          group by release, subsystem, dir
          order by perc desc
        )                     
     select dir, perc
     from   count_scat_drvs_location_out
     limit %s", subsystem, release, subsystem, release, max_rows)
  )
       
  gg_grouped_scat_drvs_rel <-     
    ggplot(grouped_scat_drvs_out, aes(x = reorder(dir, -perc), y = perc)) +    
        geom_bar(stat="identity") +
        xlab(paste("Location (dir) in ", release, sep="")) +
        ylab(paste("Perc. of scattered\ndriver features", sep = "")) + 
        theme(axis.text.y = element_text(size = gg_y_font_size)) + 
        theme(axis.title.x = element_text(size = gg_x_title_font_size)) +
        theme(axis.title.y = element_text(size = gg_y_title_font_size)) + 
        theme(title = element_text(size = gg_title_font_size)) +
        theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0, size = gg_x_font_size)) + 
        theme(legend.title=element_text(size = gg_x_title_font_size)) + 
        theme(legend.text=element_text(size = gg_x_title_font_size))  
    
#  gg_grouped_scat_drvs_rel <- 
#    ggplot(grouped_scat_drvs_out, aes(x = release, y = perc, shape = dir)) +
#    geom_point(size = shape_size) +
#    xlab("Release") +
#    ylab(paste("Perc. of scattered\ndriver features", sep = "")) + 
#    theme(axis.text.y = element_text(size = gg_y_font_size)) + 
#    theme(axis.title.x = element_text(size = gg_x_title_font_size)) +
#    theme(axis.title.y = element_text(size = gg_y_title_font_size)) + 
#    theme(title = element_text(size = gg_title_font_size)) +
#    theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0, size = gg_x_font_size)) + 
#    geom_line(aes(x = as.numeric(factor(release)), y = perc),color = "black") +
#    theme(legend.title=element_text(size = gg_x_title_font_size)) + 
#    theme(legend.text=element_text(size = gg_x_title_font_size)) +       
#    scale_y_continuous(breaks = seq(0, ymax_rel, by = step_rel)) +
#    coord_cartesian(ylim = c(0, ymax_rel))  +      
#    theme(legend.position="top")         
       
  if (show_plot) {
#     print(gg_grouped_scat_drvs_abs)  
     print(gg_grouped_scat_drvs_rel)
  }
  
  if (! is.null(out_rel))
     ggsave(gg_grouped_scat_drvs_rel, file = out_rel)   
    
#  if (! is.null(out_rel))
#     ggsave(gg_grouped_scat_drvs_rel, height = ht, file = out_rel)  
     
  return(grouped_scat_drvs_out)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
