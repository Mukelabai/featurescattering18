#!/usr/bin/Rscript

require(ggplot2)
require(RPostgreSQL)
require(reshape)
require(robustbase)
require(ineq)

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

library(sqldf)  

options(sqldf.RPostgreSQL.user = "postgres", 
  sqldf.RPostgreSQL.password = "netlinux@3",
  sqldf.RPostgreSQL.dbname = "test",
  sqldf.RPostgreSQL.host = "localhost", 
  sqldf.RPostgreSQL.port = 5432)

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
# Directory where R scripts are placed

if (! exists("conn")) 
   conn <- NULL

if (! exists("drv"))  
  drv <- NULL

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

# Output directory where graphics will be placed
img.file <- function (i) {
   res <- paste(base_dir, "../../paper/imgs/", i, sep="")    
   return(res)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

# Output directory where csv files will be placed
csv.file <- function (i) {
  res <- paste(base_dir, "../../data/csv/", i, sep="")    
  return(res)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
# Constants for ggplot

# Values on x axis
gg_x_font_size        <- 14.5

# Values on x axis
gg_y_font_size        <- gg_x_font_size

# Title for x axis
gg_x_title_font_size  <- 18

# Title for x axis
gg_y_title_font_size  <- gg_x_title_font_size

# Title for graph
gg_title_font_size    <- 18

gg_theme <- theme_bw()

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

create_c_scat_features <- function() {
  c_scat_features <- dbGetQuery(conn,
    "with refs as (
      select release.id        as release_id,               
             feature_ref.name  as feature_name,
             count(*)          as count_refs
      
      from ifdef_ref, 
           c_source_ref, 
           feature_ref,
           file,
           release
      
      where ifdef_ref.fk_c_source_ref = c_source_ref.fk_feature_ref
      and c_source_ref.fk_feature_ref = feature_ref.id
      and c_source_ref.fk_c_source_file = file.id
      and file.fk_release = release.id
      and exists (select *
                  from feature,
                       file as k_file
                  where feature.name = feature_ref.name and
                        feature.fk_kconfig_file = k_file.id and
                        k_file.fk_release = release.id)
      group by release.id, feature_ref.name
    )
    
    select release_id,
           feature_name             
    
    from refs
    where count_refs >= 2"
  )
    
  dbWriteTable(conn, "c_scat_features", c_scat_features, row.names=FALSE)  
}


#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

create_uniq_drvs <- function() {
  
  uniq_drvs <- dbGetQuery(conn, 
   "with features as (
      select distinct 
             feature.name   as feature_name,  	
             subsystem.id   as subsystem_id,
             subsystem.name as subsystem,
  	         release.id     as release_id
    
      from feature, file, release, file_info, subsystem
    
      where feature.fk_kconfig_file = file.id and
            file.fk_release = release.id      and
            file.fk_file_info = file_info.id  and
            file_info.fk_subsystem = subsystem.id
    )
    
    select distinct 
           feature_name,
           release_id
    
    from features as fts1
    
    where fts1.subsystem = 'driver' and 
        not exists (
             select * 
              from features as fts2
              where fts2.subsystem_id <> fts1.subsystem_id and
                    fts2.release_id   =  fts1.release_id   and
                    fts2.feature_name =  fts1.feature_name
             )"
  )
  dbWriteTable(conn, "uniq_drvs", uniq_drvs, row.names=FALSE)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

create_scat_drvs <- function() {
  
  scat_drvs <- dbGetQuery(conn,  
  "(select release_id,
     feature_name
     from uniq_drvs)
    
    intersect
    
    (select release_id,
     feature_name
     from c_scat_features)"
  )
  dbWriteTable(conn, "scat_drvs", scat_drvs, row.names=FALSE)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

create_scat_drvs_ifdef_refs <- function() {
  scat_drvs_ifdef_refs <- dbGetQuery(conn, 
    "select release.id       as release_id,
            release.name     as release,
            feature_ref.name as feature_name,
            file_info.path   as file_path,
            feature_ref.line as line_nbr,
            subsystem.name   as subsystem       
    
    from ifdef_ref, 
         c_source_ref,
         feature_ref,
         file, 
         release,
         file_info, 
         subsystem,
         scat_drvs     
    
    where ifdef_ref.fk_c_source_ref = c_source_ref.fk_feature_ref
          and c_source_ref.fk_feature_ref = feature_ref.id
          and c_source_ref.fk_c_source_file = file.id 
          and file.fk_file_info = file_info.id 
          and file.fk_release = release.id
          and file_info.fk_subsystem = subsystem.id 
          and feature_ref.name = scat_drvs.feature_name
          and scat_drvs.release_id = release.id
    
    order by release, feature_name, file_path, line_nbr, subsystem"
  )
  dbWriteTable(conn, "scat_drvs_ifdef_refs", scat_drvs_ifdef_refs, row.names=FALSE)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

create_views <- function () {
  create_c_scat_features()
  create_uniq_drvs()
  create_scat_drvs()
  create_scat_drvs_ifdef_refs()
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
# Database connection information

connect_db <- function() {
  
  if (! is.null(conn))
    disconnect_db()
    

  # Renews connection (connect again)
  drv  <<- dbDriver("PostgreSQL")
  conn <<- dbConnect(drv, dbname="scatdb",
                   user="scatdb_admin", 
                   password="admin777", 
                   host="localhost")  
                        
  create_views()
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

remove_views <- function() {
   dbRemoveTable(conn, "uniq_drvs")    
   dbRemoveTable(conn, "c_scat_features")   
   dbRemoveTable(conn, "scat_drvs")
   dbRemoveTable(conn, "scat_drvs_ifdef_refs")
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

disconnect_db <- function() {
   remove_views()
   dbDisconnect(conn)
   dbUnloadDriver(drv)
   conn <<- NULL
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

print_header <- function(str) {
  cat("==================================\n")
  cat(str, "\n\n")
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

get_scat_drvs <- function(s) {
  scat_s <- dbGetQuery(conn,
                       sprintf("select distinct release.name as release, 
                                       feature_name
                                from scat_drvs_ifdef_refs, release
                                where scat_drvs_ifdef_refs.release_id = release.id and
                                      subsystem = '%s'", s))  
  return(scat_s)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

gen_sample <- function (pop, sample_size) {
  rows_sample <- sample(1:nrow(pop), size = sample_size)
  sample <- pop[rows_sample, ]  
}
