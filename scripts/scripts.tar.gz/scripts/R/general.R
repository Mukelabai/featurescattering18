#!/usr/bin/Rscript

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

get_lm_slope <- function(ys, xs) {
  slope <- lm(ys ~ xs)$coefficients[2]
  return(slope)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

get_nbr_of_files_in_last_release <- function() {
  c_files <- dbGetQuery(conn, 
    "select count(file.id) as total
     from  c_source_file, file, release
     where c_source_file.fk_file = file.id and
           file.fk_release = release.id and
           release.name = 'v3.9'")
    return(c_files)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

get_nbr_of_ifdefs_in_last_release <- function() {
  ifdefs <- dbGetQuery(conn, 
    "with ifdefs_last_release as 
        (select distinct feature_ref.line as line_nbr,
                         file.id          as file_id			 
   
         from  ifdef_ref,
               c_source_ref,
               feature_ref,
               file,
               release
   
         where ifdef_ref.fk_c_source_ref = c_source_ref.fk_feature_ref and
               c_source_ref.fk_feature_ref = feature_ref.id and
               c_source_ref.fk_c_source_file = file.id and 
               file.fk_release = release.id and
               release.name = 'v3.9')
  
    select count(*) as total
    from ifdefs_last_release")
  
  return(ifdefs)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

get_count_features <- function() {

  count_features <- dbGetQuery(conn, 
    "with  
       features as (select distinct release.name as release,
                                    feature.name as feature_name
    
                    from  feature, file, release
    
                    where feature.fk_kconfig_file = file.id and
                          file.fk_release = release.id)

      select release, count(feature_name) as total
      from features
      group by release
      order by release asc") 
 
  return(count_features)   
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

get_count_scat_features <- function() {
  count_scat_features <- dbGetQuery(conn,
   "select release.name        as release,    
           count(feature_name) as total
      
    from c_scat_features, release
   
    where c_scat_features.release_id = release.id
   
    group by release.name 
    order by release.name"                     
  )
  
  return(count_scat_features)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

get_sloc_growth <- function() {
  count_sloc <- dbGetQuery(conn, 
    "select release.name              as release,
              sum(c_source_file.sloc) as total

    from  c_source_file, 
          file, 
          release

    where c_source_file.fk_file = file.id and
          file.fk_release = release.id

    group by release
    order by release asc")
  
  return(count_sloc)
}
 
#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
# Percentage growth

get_growth <- function(vals) {
  growth <- c()
  
  for(i in 2 : length(vals)) {
    growth <- c(growth, (vals[i] / vals[i - 1] - 1) * 100)
  }
  
  return(growth)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

get_count_all_uniq_drvs <- function() {
  count_all_uniq_drvs <- dbGetQuery(conn, 
  "select release.name as release,
          count(distinct feature_name) as total
   
   from uniq_drvs, release

   where uniq_drvs.release_id = release.id
   
   group by release.name")
  
  return(count_all_uniq_drvs)  
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

get_count_all_drvs <- function() {
  count_all_drvs <- dbGetQuery(conn, 
   "select release.name as release,
           count(distinct feature.name) as total
   
   from feature,
        file,
        file_info,
        subsystem,
        release
   
   where feature.fk_kconfig_file = file.id
         and file.fk_release = release.id
         and file.fk_file_info = file_info.id
         and file_info.fk_subsystem = subsystem.id 
         and subsystem.name = 'driver'
   
   group by release.name")
  
   return(count_all_drvs)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

get_loss <- function() {
  
  count_uniq_drvs <- get_count_all_uniq_drvs()
  count_all_drvs  <- get_count_all_drvs()
  
  perc <- round((1 - count_uniq_drvs$total / count_all_drvs$total) * 100, 2)
  
  return(data.frame(release = count_uniq_drvs$release, perc=perc))
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

print_summary <- function (vals, perc=FALSE) {  
     
   cat("MIN.........", if (perc) "(%)" else "",
       round(min(vals), digits = 2), "\n\n")   
   
   cat("MAX.........", if (perc) "(%)" else "",
       round(max(vals), digits = 2), "\n\n")   
   
   cat("MEAN........", if (perc) "(%)" else "", 
       round(mean(vals), digits = 2), "\n\n")
   
   cat("SD..........", if (perc) "(%)" else "",
       round(sd(vals), digits = 2), "\n\n")
   
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

print_diff <- function(vals) {
  cat("DIFF ....... ",  round(vals[length(vals)] - vals[1], 2), "\n\n") ;
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

print_rel_diff <- function(vals) {
  cat("DIFF (%).... ",  
      round(( vals[length(vals)] / vals[1] - 1 ) * 100, digits = 2), "%\n\n")      
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

print_releases_ext <- function() {

   releases_ext <- dbGetQuery(conn, 
      "with 
      ext as (select release.name as release,
                     substring(file_info.path from E'\\\\.[a-zA-Z0-9]+$') as suffix
	      from file, file_info, release
	      where file.fk_release = release.id and
                    file.fk_file_info = file_info.id)                        
      
      select ext.release as release,
             ext.suffix  as extension,
             round((100.0 * count(*) / file_count.total)::numeric, 1) as perc
      
      from ext,
           (select release.name as release,
                   count(*) as total
            from   file, file_info, release
            where  file.fk_file_info = file_info.id and
                   file_info.path <> '%/.gitignore' and
                   file_info.path <> '.gitignore'   and
                   file.fk_release = release.id
            group by release
           ) as file_count
      
      where ext.suffix <> ''           and
            ext.suffix <> '.gitignore' and
            ext.release = file_count.release and
            ext.release = file_count.release
               
      group by ext.release, extension, total
      order by release asc, perc desc")     
                          
   avg_perc <- sqldf(
      "select extension, round(avg(perc)::numeric, 1) as avg_perc
       from releases_ext
       group by extension
       order by avg_perc desc")                       

   cat("=================================\n")
   cat("Avg. extensions (whole kernel)\n")
                          
   print(head(avg_perc))     
}                  

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

get_features_per_subsystem <- function() {
  features_per_subsystem <- dbGetQuery(conn,
   "with
      features_mapped_to_subsystem as
        (select release.id     as release_id,
                release.name   as release,
	              feature.name   as feature_name,
	              subsystem.name as subsystem
	       from feature, file, file_info, subsystem, release
	       where feature.fk_kconfig_file = file.id     and
	             file.fk_release = release.id          and
	             file.fk_file_info = file_info.id      and
	             file_info.fk_subsystem = subsystem.id
	      )
      select release, subsystem, count(distinct feature_name) as total 
      from features_mapped_to_subsystem as fmap1
      where not exists (select * 
                        from  features_mapped_to_subsystem as fmap2
                        where fmap1.feature_name = fmap2.feature_name and
                              fmap1.subsystem <> fmap2.subsystem      and
                              fmap1.release_id = fmap2.release_id
                       )
      group by release, subsystem
      order by release asc")
  
  return(features_per_subsystem)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

get_count_scat_drvs <- function() {
  res <- dbGetQuery(conn, 
             "select release.name as release, count(*) as total
              from   scat_drvs, release
              where  scat_drvs.release_id = release.id
              group by release
              order by release")
  return(res)
} 

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
# General stats

count_sloc <- get_sloc_growth()

plot_line(xvals = count_sloc$release, 
   yvals = count_sloc$total, 
   xlabel = "Release", 
   ylabel = paste("Lines of source\ncode(SLOC)"),
   ht = 3, out = img.file("gg_sloc.pdf"))

print_header("SLOC growth summary")
print_summary(get_growth(count_sloc$total), TRUE)
print_rel_diff(count_sloc$total)

# . . . . . . . . . . . . . . .
# Growth of features (absolute)

count_features <- get_count_features() 
seq_releases <- as.numeric(factor(count_features$release))

print_header("Feature growth summary")
print_summary(get_growth(count_features$total), TRUE)
print_rel_diff(count_features$total)

print_header("Features lm slope coefficient: ")
cat("Slope: ", round(get_lm_slope(count_features$total, seq_releases), 2), 
    "\n\n")

plot_line(xvals = count_features$release, 
          yvals = count_features$total, 
          xlabel = "Release", 
          ylabel = "Nbr. of features", 
          ht = 3, out = img.file("gg_features.pdf"))

# . . . . . . . . . . . . . . .
# Stats relative to the latest release

print_header("Stats in v3.9")

cat("Nbr. of C files...... " ,
    get_nbr_of_files_in_last_release()$total, "\n")

cat("Nbf. of ifdefs....... ",
     get_nbr_of_ifdefs_in_last_release()$total, "\n")

cat("Nbf. of features..... ",
     subset(count_features, release == 'v3.9')$total, "\n")

cat("Total SLOC........... ", 
    subset(count_sloc, release == 'v3.9')$total, "\n\n")

# . . . . . . . . . . . . . . .

print_releases_ext()

# . . . . . . . . . . . . . . .
# Growth of scattered features 
# (absolute)

count_scat_features <- get_count_scat_features()

plot_line(xvals = count_scat_features$release, 
          yvals = count_scat_features$total, 
          xlabel = "Release", 
          ylabel = paste("Nbr. of scattered\nfeatures"), 
          ht = 4, out = img.file("gg_scat_features.pdf"))

print_header("Scattered feature (absolute) growth summary")
print_summary(get_growth(count_scat_features$total), TRUE)
print_rel_diff(count_scat_features$total)

# . . . . . . . . . . . . . . .

cat("Correlation between feature and scattered features: ", 
    round(cor(x = count_features$total, y = count_scat_features$total), 3), "\n\n")

print_header("Scattered features lm slope coefficient")
cat("Slope: ", round(get_lm_slope(count_scat_features$total, seq_releases), 2), 
    "\n\n")

print_header("Non-scattered features lm slope coefficient")
count_non_scattered_features <- data.frame(
    release = count_scat_features$release,
    total = count_features$total - count_scat_features$total
  )
  
cat("Slope: ", round(get_lm_slope(count_non_scattered_features$total, seq_releases), 2), 
    "\n\n")

count_scat_features$type = 'Scattered features'
count_non_scattered_features$type = 'Non-scattered features'

count_features_per_scat_type <- 
  rbind(count_scat_features, count_non_scattered_features)

plot_line(xvals = count_features_per_scat_type$release,          
          yvals = count_features_per_scat_type$total,
          discr = count_features_per_scat_type$type,
          xlabel = "Release",
          ylabel = "Nbr. of features",
          discrlabel = "Type",
          out = img.file("gg_features_all.pdf"),
          ht = 3.5)

# . . . . . . . . . . . . . . .
# Growth of scattered features 
# (relative)

scat_features_perc <- round((count_scat_features$total / 
                               count_features$total) * 100, 2)

plot_line(xvals = count_features$release, 
          yvals = scat_features_perc, 
          xlabel = "Release", 
          ylabel = paste("Perc. of scattered\nfeatures"), 
          ht = 4, out = img.file("gg_rel_scat_features.pdf"))

print_header("Scattered features (relative) summary")
print_summary(scat_features_perc)
print_diff(scat_features_perc)

# . . . . . . . . . . . . . . .

features_per_subsystem <- get_features_per_subsystem()

plot_line(xvals = features_per_subsystem$release, 
          yvals = features_per_subsystem$total,
          xlabel = "Release",
          ylabel = "Nbr. unique features",
          discr = features_per_subsystem$subsystem,
          discrlabel = "Subsystem", 
          ht = 4, out = img.file("gg_features_per_subsystem.pdf"))

# . . . . . . . . . . . . . . .
# Loss of driver features due to uniqueness

loss <- get_loss()

plot_line(xvals = loss$release, 
          yvals = loss$perc, 
          xlabel = "Release", 
          ylabel = "Loss perc.", 
          ht = 4, out = img.file("gg_loss.pdf"))  

print_header("Feature loss summary")
print_summary(loss$perc)