#!/usr/bin/Rscript

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

plot_line <- function(xvals, yvals, xlabel, ylabel, 
                      ystart = NULL,
                      ystep = NULL,
                      ymax = NULL,
                      ht = 3, shape_size = 2.5, 
                      discr = NULL, 
                      discrlabel = NULL, 
                      legend_position = "top",
                      out = NULL) {    
  
  
  if (is.null(discr)) {
      dataset <- data.frame(xv = xvals, yv = yvals) 
      gg_growth <- ggplot(dataset, aes(x = xv, y = yv)) 
      gg_growth <- gg_growth + gg_theme + geom_point(size = shape_size)
      gg_growth <- gg_growth + geom_line(aes(x = as.numeric(factor(xv)), y = yv))
  }
  
  else {
    dataset <- data.frame(xv = xvals, yv = yvals, zv = discr)
    gg_growth <- ggplot(dataset, aes(x = xv, y = yv, color = zv)) 
    gg_growth <- gg_growth + gg_theme + geom_point(size = shape_size)      
    gg_growth <- gg_growth + geom_line(aes(x = as.numeric(factor(xv)), y = yv, color = zv))    
    gg_growth <- gg_growth + scale_colour_brewer(name = discrlabel, palette="Set1")
  } 
  
  gg_growth <- gg_growth +    
    xlab(xlabel) +
    ylab(paste(ylabel, sep = "")) +
    theme(axis.text.y = element_text(size = gg_y_font_size)) +
    theme(axis.title.x = element_text(size = gg_x_title_font_size)) +
    theme(axis.title.y = element_text(size = gg_y_title_font_size)) +
    theme(title = element_text(size = gg_title_font_size)) +
    theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0, size = gg_x_font_size)) +
    theme(legend.title=element_text(size = gg_x_title_font_size)) +
    theme(legend.text=element_text(size = gg_x_title_font_size)) +    
    theme(legend.position=legend_position)
  
  if (! is.null(ystep)) {
    
    if (is.null(ystart))
      ystart <- 0
    
    if (is.null(ymax))
      ymax = max(yvals)
    
    gg_growth <- gg_growth + scale_y_continuous(breaks = seq(ystart, ymax + ystep, by = ystep))
  }
  
  if (show_plot)
    print(gg_growth)  
  
  if (! is.null(out)) {
    if (! is.null(ht))
      ggsave(gg_growth, height = ht, file = out)
    else
      ggsave(gg_growth, file = out)
  }
  
  return(gg_growth)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

boxdata <- function(x) { 
  s <- adjboxStats(x)$stats  
  return(c("low_whisker"=s[1], "Q1"=s[2], "Q2"=s[3], "Q3"=s[4], "top_whisker"=s[5]))
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

outliers <- function(x) {
  return(adjboxStats(x)$out)
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

plot_box_plot <- function(xvals, yvals, 
                          xlabel = "x", ylabel = "y", ymax = NULL, ystep = NULL, ht = 3, shape_size = 2.5, out = NULL) {
    
  dataset <- data.frame(xv = xvals, yv = yvals)
  
  non_outliers <- cast(xv ~ ., value = "yv", data = dataset, fun = boxdata)  
    
  # Adds median
  gg_boxplot <- ggplot(non_outliers, aes(x = xv, y = Q2)) + gg_theme
  
  # Adds main range
  gg_boxplot <- gg_boxplot + 
    geom_errorbar(aes(ymin = low_whisker, ymax = top_whisker), 
                  linetype = 1, width = 0.5) 
  
  # Adds IQR
  gg_boxplot <- gg_boxplot +
    geom_crossbar(aes(y=Q2, ymin = Q1, ymax = Q3),
                  linetype = 1, fill = 'white')
  
  # Add outliers
  
  max_threshold  <- max(non_outliers$top_whisker)
  outliers_top <- sqldf("with maxt as (
                           select xv, top_whisker as top
                           from non_outliers
                        )
                        select maxt.xv as xv, dataset.yv as yv
                        from maxt, dataset
                        where maxt.xv = dataset.xv and dataset.yv > maxt.top")  
  
  gg_boxplot <- gg_boxplot + 
    geom_point(data = outliers_top, aes(x = xv, y = yv), size = shape_size) 
  
  min_threshold  <- min(non_outliers$low_whisker)
  outliers_low <- subset(dataset, yv < min_threshold)  
  
  gg_boxplot <- gg_boxplot + 
    geom_point(data = outliers_low, aes(x = xv, y = yv), size = shape_size) 
  
  # Adds x-axis  
  gg_boxplot <- gg_boxplot + scale_x_discrete(name = xlabel)
  
  # Adds y-axis
  if (! is.null(ystep)) {
    
    if (is.null(ymax))
      ymax = max(yvals)
    
    gg_boxplot <- gg_boxplot + scale_y_continuous(breaks = seq(0, ymax + ystep, by = ystep), name = ylabel)
  }  
  else
    gg_boxplot <- gg_boxplot + ylab(paste(ylabel, sep = ""))
  
  # Adds themes
  gg_boxplot <- gg_boxplot +     
    theme(axis.text.y = element_text(size = gg_y_font_size)) + 
    theme(axis.title.x = element_text(size = gg_x_title_font_size)) +
    theme(axis.title.y = element_text(size = gg_y_title_font_size)) +           
    theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0, size = gg_x_font_size)) +
    theme(legend.position="top") 

  if (show_plot)
    print(gg_boxplot)  
  
  if (! is.null(out)) {
    if (! is.null(ht))
      ggsave(gg_boxplot, height = ht, file = out)
    else
      ggsave(gg_boxplot, file = out)
  }
  
  return(list(max = max_threshold, min = min_threshold, non_outliers=non_outliers,outliers_top=outliers_top))
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

plot_barchart <- function(xvals, yvals, 
                          xlabel = "x", 
                          ylabel = "y", 
                          ystart = NULL, 
                          ystep = NULL, 
                          ymax = NULL, 
                          ht = 3, out = NULL) {
  
  dataset <- data.frame(xv = xvals, yv = yvals)  
  
  gg_bar <- ggplot(dataset, aes(x = xv, y = yv)) + gg_theme +
    geom_bar(stat="identity") +     
    theme(axis.text.y = element_text(size = gg_y_font_size)) + 
    theme(axis.title.x = element_text(size = gg_x_title_font_size)) +
    theme(axis.title.y = element_text(size = gg_y_title_font_size)) +   
    theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0, size = gg_x_font_size)) +
    theme(legend.title=element_text(size = gg_x_title_font_size)) +
    theme(legend.text=element_text(size = gg_x_title_font_size)) +    
    xlab(xlabel) +
    ylab(paste(ylabel, sep=""))
  
  if (! is.null(ystep)) {
    
    if (is.null(ystart))
      ystart <- 0
    
    if (is.null(ymax))
      ymax = max(yvals)
    
    gg_bar <- gg_bar + scale_y_continuous(breaks = seq(ystart, ymax + ystep, by = ystep))
  }  
  
  if (show_plot)
    print(gg_bar)   
  
  if (! is.null(out)) {
    if (! is.null(ht))
      ggsave(gg_bar, height = ht, file = out)
    else
      ggsave(gg_bar, file = out)
  }
}


