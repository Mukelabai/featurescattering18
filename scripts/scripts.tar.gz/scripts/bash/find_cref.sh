#!/bin/bash

if [[ "$#" != "1" ]] ; then
  echo "Usage: find_mk.sh <feature name>" >> /dev/stderr
  exit 1
fi

ft="$1"
cd $LINUX_SRC
 
egrep "CONFIG_$1([^a-zA-Z0-9_-]|$)" -R . | egrep "^.*\.(c|h):.*$" | cut -d ':' -f1 | sort | uniq
