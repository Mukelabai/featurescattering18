#!/bin/bash

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
# Author: Leonardo Passos (lpassos@gsd.uwaterloo.ca)
# Date: January, 2014
#
#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

SCRIPTSDIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

source "$SCRIPTSDIR/utils.sh"

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

function  check_usage {

  if [[ "$#" != "1" ]] ; then
    echo "Usage: general_stats.sh <output-csv-file>" > /dev/stderr
    exit
  fi
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

function count_features {

   find -type f -name '*Kconfig*'  |  \
   xargs egrep -h "^[[:space:]]*(config|menu|menuconfig|option|choice|mainmenu)[[:space:]]+[a-zA-Z_0-9]+[[:space:]]*($|#.*)" | \
   sed 's/^\s\+//' | \
   cut -d ' ' -f2 | \
   sort -u | wc --lines | awk '{ print $1 }'
   
}


#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

function count_sloc {
   local total_sloc="0"
   
   for file in $(cat "$all_src"); do
      file_sloc=$(wc --lines "$file" | awk '{ print $1 }')
      total_sloc=$(( total_sloc + file_sloc ))
   done
   
   echo "$total_sloc"
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
# Approximates over the number of modular features

function count_modular_features {

   find -type f -name '*Kbuild*' -o -name '*Makefile*' | \
   xargs cat | sed 's/^#.*//' | sline |  \
   egrep -o "^[[:space:]]*obj-\\$\(CONFIG_[a-zA-Z0-9_]+\)[[:space:]]*(\+=|:=).*" | \
   awk -F '[()]' '{ print $2  }' | sort -u | wc --lines
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

function count_scattering_related_features {

  get_vps_from_file_list "$all_src" | \
  egrep -o -h "CONFIG_[0-9A-Za_z]+" | sed 's/_MODULE$//' | sort -u | \
  wc --lines

}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

check_usage "$@"

csv=$(get_file_full_name "$1" "$SCRIPTSDIR")
all_src="/tmp/$$.all_src"
copy_repo="/tmp/$$-repo"

#. . . . . . . . . . . .

if [[ -d "$copy_repo" ]] ; then
  rm -rf "$copy_repo"/*
else
  mkdir "$copy_repo" 
fi

git clone $LINUX_SRC "$copy_repo"

cd "$copy_repo"

#. . . . . . . . . . . .

echo "release;total_features;total_modular_features;total_scattering_related_features;total_c_files;total_sloc" > $csv

for release in $(get_releases) ; do

  git clean -f -d  

  echo "--------------------------------------"
  echo "Checking out $release"
  git checkout -f "$release" 

  total_features=$(count_features)
  echo "Number of features found: $total_features"
  
  total_modular_features=$(count_modular_features)
  echo "Number of modular features: $total_modular_features"
    
  get_all_c_src . > "$all_src"
  format_file_list_in_repo "$all_src"    
    
  total_scattering_related_features=$(count_scattering_related_features)
  echo "Number of scattering related features: $total_scattering_related_features"
  
  total_c_files=$(cat "$all_src" | wc --lines)
  echo "Number of C files found: $total_c_files"
  
  total_sloc=$(count_sloc)
  echo "Number of total SLOC: $total_sloc"
    
  echo "$release;$total_features;$total_modular_features;$total_scattering_related_features;$total_c_files;$total_sloc" >> $csv
done

rm -f "$copy_repo"

echo "Successfully created $csv file"
