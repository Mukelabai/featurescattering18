#!/bin/bash

if [[ "$#" != "1" ]] ; then
  echo "Usage: find_ft.sh <feature-list>" >> /dev/stderr
  exit 1
fi

ft_list="$1"
cd $LINUX_SRC

cat $ft_list | sed '1d' | while read line ; do

 ft=`echo $line | cut -d ';' -f1`
 release=`echo $line | cut -d ';' -f3` 
 
 git checkout -f "$release" &> /dev/null 

 type=$(find -type f -name '*Kconfig*' | xargs egrep -n -A 5 \
 "^[[:space:]]*(config|menuconfig|choice)[[:space:]]+$ft[[:space:]]*$" | \
 egrep -o "(tristate|bool|boolean|int|hex|string|def_bool|def_tristate)" | head -n 1)
 
 echo "$ft;$type"
 
done 

git checkout master
 

