#!/bin/bash

if [[ "$#" != "1" ]] ; then
  echo "Usage: find_ft.sh <feature name>" >> /dev/stderr
  exit 1
fi

ft="$1"
cd $LINUX_SRC
 
find -type f -name '*Kconfig*' | xargs egrep -n -A 5 \
 "^[[:space:]]*(config|menuconfig|choice)[[:space:]]+$ft[[:space:]]*$"

