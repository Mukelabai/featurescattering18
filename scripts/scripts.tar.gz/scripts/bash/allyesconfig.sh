#!/bin/bash

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
# Author: Leonardo Passos (lpassos@gsd.uwaterloo.ca)
# Date: January, 2014
#
#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

function check_usage {

  if [[ "$#" != "1" ]] ; then
    echo "Usage: allyesconfig.sh <output-csv-file>" > /dev/stderr
    exit
  fi
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

function get_archs {
  find arch -maxdepth 1 -type d -printf "%f\n" | grep -v "^arch$"
}

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

SCRIPTSDIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

source "$SCRIPTSDIR/utils.sh"

check_usage "$@"

#. . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

ORIGINAL_ARCH=$ARCH
cd $LINUX_SRC

csv=$(get_file_full_name "$1" "$SCRIPTSDIR")

echo "release;architecture;feature_name" > $csv

for release in $(get_releases) ; do

   echo "--------------------------------------"
   echo "Checking out $release"
   git checkout -f "$release"          


  for arch in $(get_archs) ; do 

     git clean -f -d 
     make mrproper 

     echo "--------------------------------------"
     echo "---> Checking $arch"

     export ARCH="$arch"
         
     timeout -t 20  make allyesconfig &> /dev/null
     
     if [[ ! -f ".config" ]]; then
        echo "$release;$arch;NULL"  >> "$csv"
     else       
        cat ".config" | egrep "^[A-Za-z0-9_]+=.*$"  | \
          awk -F '=' -v rel=$release -v arc=$arch \
          '{ printf("%s;%s;%s\n", rel, arc, $1) }' >> "$csv"
     fi
  
  done
  
done

export ARCH="$ORIGINAL_ARCH"


